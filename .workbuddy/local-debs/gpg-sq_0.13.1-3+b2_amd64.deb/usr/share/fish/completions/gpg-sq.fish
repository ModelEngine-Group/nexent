complete -c gpg-sq -s s -l sign -d 'make a signature' -r
complete -c gpg-sq -l clear-sign -d 'make a clear text signature' -r
complete -c gpg-sq -s b -l detach-sign -d 'make a detached signature' -r
complete -c gpg-sq -s e -l encrypt -d 'encrypt data' -r
complete -c gpg-sq -s c -l symmetric -d 'encryption only with symmetric cipher' -r
complete -c gpg-sq -s d -l decrypt -d 'decrypt data (default)' -r
complete -c gpg-sq -l verify -d 'verify a signature' -r
complete -c gpg-sq -s k -l list-keys -d 'list keys' -r
complete -c gpg-sq -l list-signatures -d 'list keys and signatures' -r
complete -c gpg-sq -l check-signatures -d 'list and check key signatures' -r
complete -c gpg-sq -l fingerprint -d 'list keys and fingerprints' -r
complete -c gpg-sq -s K -l list-secret-keys -d 'list secret keys' -r
complete -c gpg-sq -l generate-key -d 'generate a new key pair' -r
complete -c gpg-sq -l quick-generate-key -d 'quickly generate a new key pair' -r
complete -c gpg-sq -l quick-add-uid -d 'quickly add a new user-id' -r
complete -c gpg-sq -l quick-revoke-uid -d 'quickly revoke a user-id' -r
complete -c gpg-sq -l quick-set-expire -d 'quickly set a new expiration date' -r
complete -c gpg-sq -l full-generate-key -d 'full featured key pair generation' -r
complete -c gpg-sq -l generate-revocation -d 'generate a revocation certificate' -r
complete -c gpg-sq -l delete-keys -d 'remove keys from the public keyring' -r
complete -c gpg-sq -l delete-secret-keys -d 'remove keys from the secret keyring' -r
complete -c gpg-sq -l quick-sign-key -d 'quickly sign a key' -r
complete -c gpg-sq -l quick-lsign-key -d 'quickly sign a key locally' -r
complete -c gpg-sq -l quick-revoke-sig -d 'quickly revoke a key signature' -r
complete -c gpg-sq -l sign-key -d 'sign a key' -r
complete -c gpg-sq -l lsign-key -d 'sign a key locally' -r
complete -c gpg-sq -l edit-key -d 'sign or edit a key' -r
complete -c gpg-sq -l change-passphrase -d 'change a passphrase' -r
complete -c gpg-sq -l export -d 'export keys' -r
complete -c gpg-sq -l send-keys -d 'export keys to a keyserver' -r
complete -c gpg-sq -l receive-keys -d 'import keys from a keyserver' -r
complete -c gpg-sq -l search-keys -d 'search for keys on a keyserver' -r
complete -c gpg-sq -l refresh-keys -d 'update all keys from a keyserver' -r
complete -c gpg-sq -l import -d 'import/merge keys' -r
complete -c gpg-sq -l update-trustdb -d 'update the trust database' -r
complete -c gpg-sq -l print-md -d 'print message digests' -r
complete -c gpg-sq -l server -d 'run in server mode' -r
complete -c gpg-sq -l tofu-policy -d 'set the TOFU policy for a key' -r
complete -c gpg-sq -l x-sequoia-parcimonie -d 'continuously update certificates' -r
complete -c gpg-sq -s v -l verbose -d 'verbose' -r
complete -c gpg-sq -s q -l quiet -d 'be somewhat more quiet' -r
complete -c gpg-sq -l options -d 'read options from FILE' -r
complete -c gpg-sq -l log-file -d 'write server mode logs to FILE' -r
complete -c gpg-sq -l default-key -d 'use NAME as default secret key' -r
complete -c gpg-sq -l encrypt-to -d 'encrypt to user ID NAME as well' -r
complete -c gpg-sq -l group -d 'set up email aliases' -r
complete -c gpg-sq -l openpgp -d 'use strict OpenPGP behavior' -r
complete -c gpg-sq -s n -l dry-run -d 'do not make any changes' -r
complete -c gpg-sq -s i -l interactive -d 'prompt before overwriting' -r
complete -c gpg-sq -s a -l armor -d 'create ascii armored output' -r
complete -c gpg-sq -s o -l output -d 'write output to FILE' -r
complete -c gpg-sq -l textmode -d 'use canonical text mode' -r
complete -c gpg-sq -s z -d 'set compress level to N (0 disables)' -r
complete -c gpg-sq -l auto-key-locate -d 'use MECHANISMS to locate keys by mail address' -r
complete -c gpg-sq -l auto-key-import -d 'import missing key from a signature' -r
complete -c gpg-sq -l include-key-block -d 'include the public key in signatures' -r
complete -c gpg-sq -l disable-dirmngr -d 'disable all access to the dirmngr' -r
complete -c gpg-sq -s r -l recipient -d 'encrypt for USER-ID' -r
complete -c gpg-sq -s u -l local-user -d 'use USER-ID to sign or decrypt' -r
complete -c gpg-sq -l x-sequoia-autostart-parcimonie -d 'automatically start daemon to update certs' -r
complete -c gpg-sq -s h -l help -d 'Print help (see more with \'--help\')'
complete -c gpg-sq -s V -l version -d 'Print version'
