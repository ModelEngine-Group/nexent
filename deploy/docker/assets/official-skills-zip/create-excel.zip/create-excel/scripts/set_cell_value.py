#!/usr/bin/env python3
"""Set a value in a specific cell of an existing Excel workbook."""

import argparse
import json
import os
import re
import sys

DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def _col_letter_to_index(col_str):
    result = 0
    for char in col_str.upper():
        result = result * 26 + (ord(char) - ord('A') + 1)
    return result - 1


def _parse_cell(cell_str):
    match = re.match(r'^([A-Za-z]+)(\d+)$', cell_str.strip())
    if not match:
        raise ValueError(f"Invalid cell address: {cell_str}")
    col_str, row_str = match.group(1), match.group(2)
    return _col_letter_to_index(col_str), int(row_str) - 1


def set_cell_value(path: str, cell: str, value, sheet_index: int = 0,
                   working_dir: str = None) -> dict:
    """Set a value in a specific cell of an Excel workbook."""
    from openpyxl import load_workbook

    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Workbook not found: {abs_path}")

    col_idx, row_idx = _parse_cell(cell)

    wb = load_workbook(abs_path)

    if sheet_index < 0 or sheet_index >= len(wb.worksheets):
        raise ValueError(f"Sheet index {sheet_index} out of range")

    ws = wb.worksheets[sheet_index]
    ws.cell(row=row_idx + 1, column=col_idx + 1, value=value)

    wb.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "cell": cell,
        "value": value,
        "sheet_index": sheet_index
    }


def main():
    parser = argparse.ArgumentParser(description="Set a cell value in an Excel workbook")
    parser.add_argument("--path", "-p", required=True, help="Workbook file path")
    parser.add_argument("--cell", "-c", required=True, help="Cell address, e.g. A1")
    parser.add_argument("--value", "-v", required=True, help="Cell value")
    parser.add_argument("--sheet-index", "-i", type=int, default=0,
                        help="Sheet index (default: 0)")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = set_cell_value(args.path, args.cell, args.value,
                                 args.sheet_index, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
