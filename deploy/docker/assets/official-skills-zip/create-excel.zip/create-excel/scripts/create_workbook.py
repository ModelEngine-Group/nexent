#!/usr/bin/env python3
"""Create a new blank Excel workbook."""

import argparse
import json
import os
import sys
from pathlib import Path

DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def create_workbook(path: str, sheet_name: str = "Sheet1", working_dir: str = None) -> dict:
    """Create a new blank Excel workbook.

    Args:
        path: Output file name
        sheet_name: Name of the first sheet (default "Sheet1")
        working_dir: Working directory (defaults to /mnt/nexent)
    """
    from openpyxl import Workbook

    if not path.lower().endswith((".xlsx", ".xlsm")):
        path += ".xlsx"

    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))
    Path(abs_path).parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name[:31] if sheet_name else "Sheet1"

    wb.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path
    }


def main():
    parser = argparse.ArgumentParser(description="Create a new Excel workbook")
    parser.add_argument("--path", "-p", required=True, help="Output file path")
    parser.add_argument("--sheet-name", "-n", default="Sheet1",
                        help="Name of the first sheet (default: Sheet1)")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = create_workbook(args.path, args.sheet_name, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
