#!/usr/bin/env python3
"""Add a data table to an existing Excel workbook sheet."""

import argparse
import json
import os
import re
import sys

DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def _col_letter_to_index(col_str):
    result = 0
    for char in col_str.upper():
        result = result * 26 + (ord(char) - ord('A') + 1)
    return result - 1


def _parse_cell(cell_str):
    match = re.match(r'^([A-Za-z]+)(\d+)$', cell_str.strip())
    if not match:
        raise ValueError(f"Invalid cell address: {cell_str}")
    col_str, row_str = match.group(1), match.group(2)
    return _col_letter_to_index(col_str), int(row_str) - 1


def add_table(path: str, data: str, sheet_index: int = 0, start_cell: str = "A1",
              has_header: bool = True, working_dir: str = None) -> dict:
    """Add a data table to an existing Excel workbook sheet."""
    from openpyxl import load_workbook

    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Workbook not found: {abs_path}")

    try:
        table_data = json.loads(data)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON data: {e}")

    if not table_data or not isinstance(table_data, list):
        raise ValueError("Table data must be a non-empty list of rows")

    rows = len(table_data)
    cols = len(table_data[0]) if table_data[0] else 0
    if rows < 1 or cols < 1:
        raise ValueError("Table must have at least one row and one column")

    wb = load_workbook(abs_path)

    if sheet_index < 0 or sheet_index >= len(wb.worksheets):
        raise ValueError(f"Sheet index {sheet_index} out of range")

    ws = wb.worksheets[sheet_index]

    start_col, start_row = _parse_cell(start_cell)

    if has_header and rows > 0:
        header_row = table_data[0]
        for j, hdr in enumerate(header_row):
            ws.cell(row=start_row + 1, column=start_col + j + 1, value=hdr)
        data_rows = table_data[1:]
        data_start = start_row + 2
    else:
        data_rows = table_data
        data_start = start_row + 1

    for i, row_data in enumerate(data_rows):
        for j, cell_data in enumerate(row_data):
            ws.cell(row=data_start + i, column=start_col + j + 1, value=cell_data)

    wb.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "rows": rows,
        "columns": cols,
        "has_header": has_header,
        "start_cell": start_cell
    }


def main():
    parser = argparse.ArgumentParser(description="Add a data table to an Excel workbook sheet")
    parser.add_argument("--path", "-p", required=True, help="Workbook file path")
    parser.add_argument("--data", "-d", required=True, help="Table data as JSON array")
    parser.add_argument("--sheet-index", "-i", type=int, default=0,
                        help="Sheet index (default: 0)")
    parser.add_argument("--start-cell", "-c", default="A1",
                        help="Top-left anchor cell (default: A1)")
    parser.add_argument("--has-header", action="store_true", default=True,
                        help="First row is header (default: true)")
    parser.add_argument("--no-header", dest="has_header", action="store_false",
                        help="First row is not a header")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = add_table(args.path, args.data, args.sheet_index,
                           args.start_cell, args.has_header, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
