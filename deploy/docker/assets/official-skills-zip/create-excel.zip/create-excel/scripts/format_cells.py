#!/usr/bin/env python3
"""Apply formatting to cells in an Excel workbook."""

import argparse
import json
import os
import re
import sys
from typing import Any, Dict

DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def _col_letter_to_index(col_str):
    result = 0
    for char in col_str.upper():
        result = result * 26 + (ord(char) - ord('A') + 1)
    return result - 1


def _parse_cell(cell_str):
    match = re.match(r'^([A-Za-z]+)(\d+)$', cell_str.strip())
    if not match:
        raise ValueError(f"Invalid cell address: {cell_str}")
    col_str, row_str = match.group(1), match.group(2)
    return _col_letter_to_index(col_str), int(row_str) - 1


def _parse_range(range_str):
    """Parse cell range like 'A1:B5' into start and end coordinates."""
    match = re.match(r'^([A-Za-z]+\d+):([A-Za-z]+\d+)$', range_str.strip())
    if not match:
        raise ValueError(f"Invalid range format: {range_str}. Use 'A1:B5'")
    start_col, start_row = _parse_cell(match.group(1))
    end_col, end_row = _parse_cell(match.group(2))
    return (start_col, start_row), (end_col, end_row)


def _apply_font(cell, font_spec: Dict[str, Any]):
    """Apply font formatting to a cell."""
    from openpyxl.styles import Font

    font_kwargs = {}
    if "bold" in font_spec:
        font_kwargs["bold"] = font_spec["bold"]
    if "italic" in font_spec:
        font_kwargs["italic"] = font_spec["italic"]
    if "size" in font_spec:
        font_kwargs["size"] = float(font_spec["size"])
    if "color" in font_spec:
        font_kwargs["color"] = font_spec["color"]
    if "name" in font_spec:
        font_kwargs["name"] = font_spec["name"]

    if font_kwargs:
        cell.font = Font(**font_kwargs)


def _apply_fill(cell, fill_spec: Dict[str, Any]):
    """Apply fill/background formatting to a cell."""
    from openpyxl.styles import PatternFill

    fill_type = fill_spec.get("type", "solid")
    fg_color = fill_spec.get("fgColor")

    if fill_type and fg_color:
        cell.fill = PatternFill(fill_type=fill_type, fgColor=fg_color)


def _apply_border(cell, border_spec: Dict[str, Any]):
    """Apply border formatting to a cell."""
    from openpyxl.styles import Border, Side

    def parse_side(side_spec):
        if not side_spec:
            return Side()
        return Side(
            style=side_spec.get("style"),
            color=side_spec.get("color")
        )

    cell.border = Border(
        left=parse_side(border_spec.get("left")),
        right=parse_side(border_spec.get("right")),
        top=parse_side(border_spec.get("top")),
        bottom=parse_side(border_spec.get("bottom"))
    )


def _apply_alignment(cell, align_spec: Dict[str, Any]):
    """Apply alignment formatting to a cell."""
    from openpyxl.styles import Alignment

    align_kwargs = {}
    if "horizontal" in align_spec:
        align_kwargs["horizontal"] = align_spec["horizontal"]
    if "vertical" in align_spec:
        align_kwargs["vertical"] = align_spec["vertical"]
    if "wrap_text" in align_spec:
        align_kwargs["wrap_text"] = align_spec["wrap_text"]

    if align_kwargs:
        cell.alignment = Alignment(**align_kwargs)


def _apply_number_format(cell, number_format: str):
    """Apply number format to a cell."""
    cell.number_format = number_format


def format_cells(path: str, range_or_cell: str, formatting: str,
                 sheet_index: int = 0, working_dir: str = None) -> dict:
    """Apply formatting to a cell or range of cells in an Excel workbook.

    Args:
        path: Workbook file path
        range_or_cell: Cell address (e.g., 'A1') or range (e.g., 'A1:B5')
        formatting: JSON string with formatting options
        sheet_index: Sheet index to modify (default: 0)
        working_dir: Working directory (defaults to /mnt/nexent)
    """
    from openpyxl import load_workbook

    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Workbook not found: {abs_path}")

    try:
        format_spec = json.loads(formatting)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON formatting: {e}")

    wb = load_workbook(abs_path)

    if sheet_index < 0 or sheet_index >= len(wb.worksheets):
        raise ValueError(f"Sheet index {sheet_index} out of range")

    ws = wb.worksheets[sheet_index]

    if ":" in range_or_cell:
        (start_col, start_row), (end_col, end_row) = _parse_range(range_or_cell)
    else:
        start_col, start_row = _parse_cell(range_or_cell)
        end_col, end_row = start_col, start_row

    cells_formatted = 0

    for row in range(start_row, end_row + 1):
        for col in range(start_col, end_col + 1):
            cell = ws.cell(row=row + 1, column=col + 1)

            if "font" in format_spec:
                _apply_font(cell, format_spec["font"])
            if "fill" in format_spec:
                _apply_fill(cell, format_spec["fill"])
            if "border" in format_spec:
                _apply_border(cell, format_spec["border"])
            if "alignment" in format_spec:
                _apply_alignment(cell, format_spec["alignment"])
            if "number_format" in format_spec:
                _apply_number_format(cell, format_spec["number_format"])

            cells_formatted += 1

    wb.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "sheet_index": sheet_index,
        "range": range_or_cell,
        "cells_formatted": cells_formatted
    }


def main():
    parser = argparse.ArgumentParser(description="Apply formatting to cells in an Excel workbook")
    parser.add_argument("--path", "-p", required=True, help="Workbook file path")
    parser.add_argument("--range", "-r", required=True,
                        help="Cell address (e.g., A1) or range (e.g., A1:B5)")
    parser.add_argument("--formatting", "-f", required=True,
                        help='JSON formatting spec (e.g., \'{"font": {"bold": true}, "number_format": "0.00"}\')')
    parser.add_argument("--sheet-index", "-i", type=int, default=0,
                        help="Sheet index (default: 0)")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = format_cells(args.path, args.range, args.formatting,
                              args.sheet_index, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
