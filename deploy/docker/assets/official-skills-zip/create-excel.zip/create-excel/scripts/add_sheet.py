#!/usr/bin/env python3
"""Add a new sheet to an existing Excel workbook."""

import argparse
import json
import os
import sys

DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def add_sheet(path: str, sheet_name: str = None, sheet_index: int = None,
              working_dir: str = None) -> dict:
    """Add a new sheet to an existing Excel workbook.

    Args:
        path: Workbook file path
        sheet_name: Name of the new sheet (auto-generated if not provided)
        sheet_index: Position to insert the sheet (at end if not provided)
        working_dir: Working directory (defaults to /mnt/nexent)
    """
    from openpyxl import load_workbook

    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Workbook not found: {abs_path}")

    wb = load_workbook(abs_path)

    existing_names = [ws.title for ws in wb.worksheets]

    if sheet_name is None:
        counter = 1
        while True:
            candidate = f"Sheet{counter}"
            if candidate not in existing_names:
                sheet_name = candidate
                break
            counter += 1

    if sheet_name in existing_names:
        raise ValueError(f"Sheet '{sheet_name}' already exists in workbook")

    sheet_name = sheet_name[:31]

    if sheet_index is not None:
        if sheet_index < 0:
            sheet_index = 0
        if sheet_index > len(wb.worksheets):
            sheet_index = len(wb.worksheets)
        wb.create_sheet(title=sheet_name, index=sheet_index)
        inserted_index = sheet_index
    else:
        wb.create_sheet(title=sheet_name)
        inserted_index = len(wb.worksheets) - 1

    wb.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "sheet_name": sheet_name,
        "sheet_index": inserted_index,
        "total_sheets": len(wb.worksheets)
    }


def main():
    parser = argparse.ArgumentParser(description="Add a new sheet to an Excel workbook")
    parser.add_argument("--path", "-p", required=True, help="Workbook file path")
    parser.add_argument("--sheet-name", "-n", default=None,
                        help="Name of the new sheet (auto-generated if not provided)")
    parser.add_argument("--sheet-index", "-i", type=int, default=None,
                        help="Position to insert the sheet (at end if not provided)")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = add_sheet(args.path, args.sheet_name, args.sheet_index, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
