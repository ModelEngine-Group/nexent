#!/usr/bin/env python3
"""Generate a complete Excel workbook from a structured specification.

This script supports two input formats:
1. Simple format: columns and data without explicit formulas
2. Advanced format: full JSON spec with formulas and formatting
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime, date
from pathlib import Path

DEFAULT_OUTPUT_DIR = "/mnt/nexent"


def _col_letter_to_index(col_str):
    """Convert column letter(s) like 'A', 'AB' to 0-based index."""
    result = 0
    for char in col_str.upper():
        result = result * 26 + (ord(char) - ord('A') + 1)
    return result - 1


def _parse_cell(cell_str):
    """Parse a cell address like 'A1' into (col_index, row_index) both 0-based."""
    match = re.match(r'^([A-Za-z]+)(\d+)$', cell_str.strip())
    if not match:
        raise ValueError(f"Invalid cell address: {cell_str}")
    col_str, row_str = match.group(1), match.group(2)
    col_idx = _col_letter_to_index(col_str)
    row_idx = int(row_str) - 1
    return col_idx, row_idx


def _index_to_col_letter(col_idx):
    """Convert 0-based column index to letter(s)."""
    result = ""
    col_idx += 1
    while col_idx:
        col_idx, remainder = divmod(col_idx - 1, 26)
        result = chr(ord('A') + remainder) + result
    return result


def _is_date_string(value):
    """Check if value looks like a date string."""
    if not isinstance(value, str):
        return False
    patterns = [
        r'^\d{4}-\d{2}-\d{2}$',
        r'^\d{4}/\d{2}/\d{2}$',
        r'^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}',
    ]
    for pattern in patterns:
        if re.match(pattern, value.strip()):
            return True
    return False


def _parse_date(value):
    """Parse date string into Python date object."""
    if isinstance(value, (datetime, date)):
        return value
    if not isinstance(value, str):
        return None
    formats = ['%Y-%m-%d', '%Y/%m/%d', '%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', '%Y/%m/%d %H:%M:%S']
    for fmt in formats:
        try:
            return datetime.strptime(value.strip(), fmt)
        except ValueError:
            continue
    return None


def _write_cell(ws, row_idx, col_idx, value, number_format=None):
    """Write a value to a cell with optional formatting."""
    cell = ws.cell(row=row_idx + 1, column=col_idx + 1)

    if value is None or value == "":
        cell.value = None
        return

    if _is_date_string(value):
        parsed_date = _parse_date(value)
        if parsed_date:
            cell.value = parsed_date
            cell.number_format = number_format or 'YYYY-MM-DD'
            return

    cell.value = value
    if number_format:
        cell.number_format = number_format


def _apply_row_data(ws, row_idx, start_col_idx, row_data, number_formats=None):
    """Write a row of data with formatting."""
    for j, cell_data in enumerate(row_data):
        if cell_data is None:
            continue
        col_idx = start_col_idx + j
        cell_format = None
        if number_formats and j < len(number_formats) and number_formats[j]:
            cell_format = number_formats[j]
        _write_cell(ws, row_idx, col_idx, cell_data, cell_format)


def _generate_auto_formulas(spec, wb):
    """Generate formulas based on column types if auto_formula is enabled."""
    sheets = spec.get("sheets", [])
    for sheet_idx, sheet_spec in enumerate(sheets):
        if not sheet_spec.get("auto_formula", False):
            continue

        tables = sheet_spec.get("tables", [])
        for table in tables:
            header = table.get("header", [])
            start_cell = table.get("start_cell", "A1")
            start_col, start_row = _parse_cell(start_cell)

            if table.get("has_header", True):
                start_row += 1

            for col_idx, col_name in enumerate(header):
                col_letter = _index_to_col_letter(start_col + col_idx)

                if "金额" in col_name or "总额" in col_name or "销售额" in col_name or "总价" in col_name:
                    for row in range(start_row + 1, 100):
                        prev_letter = _index_to_col_letter(start_col + col_idx - 1)
                        if prev_letter and col_idx > 0:
                            ws = wb.worksheets[sheet_idx]
                            formula = f"={prev_letter}{row}*{_index_to_col_letter(start_col + col_idx - 1 + 1) if col_idx > 1 else ''}"
                            if col_idx >= 2:
                                formula = f"={_index_to_col_letter(col_idx - 1)}{row}*{_index_to_col_letter(col_idx)}{row}"


def generate_xlsx(spec: dict, output_path: str = None, working_dir: str = None) -> dict:
    """Generate a complete Excel workbook from a structured specification.

    Simplified spec format:
    {
        "title": "Workbook Title",
        "sheets": [
            {
                "name": "Sheet Name",
                "columns": ["Col1", "Col2", ...],  # Simplified column headers
                "data": [[val1, val2, ...], ...],   # 2D array of data
                "auto_formula": true,                 # Auto-generate formula columns
                "date_columns": [0, 3],              # Column indices for date formatting
                "number_columns": [4, 5],             # Column indices for number formatting
                "column_widths": {"A": 15, "B": 12},
            }
        ]
    }

    Full spec format (also supported):
    {
        "sheets": [
            {
                "name": "Sheet Name",
                "tables": [...],
                "cells": [...],
            }
        ]
    }
    """
    from openpyxl import Workbook
    from openpyxl.utils import get_column_letter

    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    if output_path is None:
        output_path = spec.get("file_name", spec.get("title", "output.xlsx"))

    if not output_path.lower().endswith((".xlsx", ".xlsm")):
        output_path += ".xlsx"

    abs_path = os.path.abspath(os.path.join(working_dir, output_path))
    Path(abs_path).parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()

    sheets = spec.get("sheets", [])
    if not sheets:
        wb.active.title = str(spec.get("title", "Sheet1"))[:31]
    else:
        for idx, sheet_spec in enumerate(sheets):
            if idx == 0:
                ws = wb.active
            else:
                ws = wb.create_sheet()

            sheet_name = sheet_spec.get("name", f"Sheet{idx + 1}")
            ws.title = str(sheet_name)[:31]

            if "columns" in sheet_spec and "data" in sheet_spec:
                _process_simple_format(ws, sheet_spec)
            elif "tables" in sheet_spec:
                _process_full_format(ws, sheet_spec)

            column_widths = sheet_spec.get("column_widths", {})
            for col_letter, width in column_widths.items():
                if width and width > 0:
                    col_idx = _col_letter_to_index(col_letter)
                    ws.column_dimensions[get_column_letter(col_idx + 1)].width = width

            row_heights = sheet_spec.get("row_heights", {})
            for row_num_str, height in row_heights.items():
                if height and height > 0:
                    ws.row_dimensions[int(row_num_str)].height = height

    wb.save(abs_path)

    stat = os.stat(abs_path)
    return {
        "status": "success",
        "file_path": output_path,
        "absolute_path": abs_path,
        "file_name": os.path.basename(abs_path),
        "file_size_bytes": stat.st_size,
        "file_size_formatted": _format_size(stat.st_size),
        "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "message": "Workbook created successfully."
    }


def _process_simple_format(ws, sheet_spec):
    """Process simplified format with columns and data."""
    columns = sheet_spec.get("columns", [])
    data = sheet_spec.get("data", [])
    start_cell = sheet_spec.get("start_cell", "A1")
    start_col, start_row = _parse_cell(start_cell)

    date_columns = sheet_spec.get("date_columns", [])
    number_columns = sheet_spec.get("number_columns", [])
    currency_columns = sheet_spec.get("currency_columns", [])

    for col_idx, col_name in enumerate(columns):
        if col_name:
            ws.cell(row=start_row + 1, column=start_col + col_idx + 1, value=col_name)

    for row_idx, row_data in enumerate(data):
        if not row_data:
            continue
        for col_idx, cell_value in enumerate(row_data):
            col_num = start_col + col_idx
            cell_format = None

            if col_idx in date_columns:
                cell_format = 'YYYY-MM-DD'
            elif col_idx in currency_columns:
                cell_format = '$#,##0.00'
            elif col_idx in number_columns:
                cell_format = '#,##0'

            _write_cell(ws, start_row + row_idx + 2, col_num, cell_value, cell_format)


def _process_full_format(ws, sheet_spec):
    """Process full format with tables, cells, and formulas."""
    tables = sheet_spec.get("tables", [])
    for table_spec in tables:
        header = table_spec.get("header", [])
        data = table_spec.get("data", [])
        has_header = table_spec.get("has_header", True)
        start_cell = table_spec.get("start_cell", "A1")
        column_formats = table_spec.get("column_formats", [])

        start_col, start_row = _parse_cell(start_cell)

        if has_header and header:
            for j, hdr in enumerate(header):
                if hdr is not None and hdr != "":
                    ws.cell(row=start_row + 1, column=start_col + j + 1, value=hdr)
            data_start_row = start_row + 1
        else:
            data_start_row = start_row

        for i, row_data in enumerate(data):
            if not row_data:
                continue
            _apply_row_data(ws, data_start_row + i, start_col, row_data, column_formats)

    individual_cells = sheet_spec.get("cells", [])
    for cell_spec in individual_cells:
        cell_addr_str = cell_spec.get("cell", "")
        value = cell_spec.get("value")
        cell_format = cell_spec.get("format")
        if cell_addr_str:
            col_idx, row_idx = _parse_cell(cell_addr_str)
            _write_cell(ws, row_idx + 1, col_idx, value, cell_format)


def _format_size(size_bytes: int) -> str:
    """Format file size in human-readable format."""
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def main():
    parser = argparse.ArgumentParser(
        description="Generate a complete Excel workbook from a specification"
    )
    parser.add_argument("--spec", "-s", required=True,
                        help="Workbook specification as JSON string")
    parser.add_argument("--output", "-o", default=None,
                        help="Output file name (default: from spec)")
    parser.add_argument("--spec-file", "-f", default=None,
                        help="Path to JSON file containing the specification")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        if args.spec_file:
            with open(args.spec_file, "r", encoding="utf-8") as f:
                spec = json.load(f)
        else:
            spec = json.loads(args.spec)

        result = generate_xlsx(spec, args.output, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except json.JSONDecodeError as e:
        print(json.dumps({
            "status": "error",
            "message": f"Invalid JSON specification: {e}",
            "hint": "Make sure quotes are properly escaped. Use 'json.dumps()' with ensure_ascii=False."
        }, ensure_ascii=False, indent=2))
        sys.exit(1)
    except Exception as e:
        print(json.dumps({
            "status": "error",
            "message": str(e),
            "type": type(e).__name__
        }, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
