#!/usr/bin/env python3
"""
绩效管理Word文档导出工具（完整版）
支持文档类型：kpi_target / okr_target / progress_report / evaluation_report / interview_guide / pip_plan
用法：python performance_docx_exporter.py -t <type> -i <input.json> -o <output.docx>

设计原则：
1. 数据结构自适应 — 兼容多种JSON key命名风格（驼峰/下划线/中划线）
2. 字段完整渲染 — 所有输入字段均输出到文档，不遗漏
3. 缺失字段优雅降级 — 字段不存在时显示"-"而非报错
"""

import sys
import json
import argparse
from pathlib import Path
from docx import Document
from docx.shared import Pt, Cm, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

# ==================== 样式配置 ====================

STYLE_CONFIG = {
    "colors": {
        "primary": "1A56DB",
        "secondary": "2D3748",
        "accent": "E86C00",
        "success": "0E9F6E",
        "danger": "E53E3E",
        "warning": "D97706",
        "text": "1F2937",
        "light_text": "64748B",
        "bg_header": "F0F4FF",
        "white": "FFFFFF",
    },
    "fonts": {
        "cover_title": 28,
        "cover_subtitle": 16,
        "h1": 22,
        "h2": 16,
        "h3": 13,
        "body": 11,
        "small": 9,
        "table_header": 10,
        "table_body": 10,
        "chinese_font": "微软雅黑",
        "code_font": "Consolas",
    },
    "margins": {
        "top_cm": 2.54,
        "bottom_cm": 2.54,
        "left_cm": 3.17,
        "right_cm": 3.17,
    },
}


# ==================== 公共工具函数 ====================

def safe_get(d, *keys, default=""):
    """安全获取嵌套字典值，支持多个候选key名"""
    if not isinstance(d, dict):
        return default
    for key in keys:
        if key in d:
            val = d[key]
            if val is not None and val != "":
                return val
    return default


def safe_str(val, default="-"):
    """安全转字符串"""
    if val is None or val == "" or val == []:
        return default
    if isinstance(val, (list, dict)):
        return json.dumps(val, ensure_ascii=False)
    return str(val)


def set_cell_shading(cell, color_hex):
    """设置单元格背景色"""
    shading = OxmlElement('w:shd')
    shading.set(qn('w:fill'), color_hex)
    shading.set(qn('w:val'), 'clear')
    cell._tc.get_or_add_tcPr().append(shading)


# set_cell_border omitted — not needed for current templates


def add_styled_paragraph(doc, text, font_size=11, bold=False, color=None, alignment=None,
                         space_before=None, space_after=None, font_name="微软雅黑",
                         italic=False, underline=False):
    """添加样式化段落"""
    p = doc.add_paragraph()
    if alignment:
        p.alignment = alignment
    if space_before:
        p.paragraph_format.space_before = Pt(space_before)
    if space_after:
        p.paragraph_format.space_after = Pt(space_after)
    run = p.add_run(str(text) if text else "")
    run.font.size = Pt(font_size)
    run.font.name = font_name
    run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)
    if bold:
        run.font.bold = True
    if italic:
        run.font.italic = True
    if underline:
        run.font.underline = True
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    return p


def setup_page_style(doc):
    """设置页面样式"""
    section = doc.sections[0]
    section.top_margin = Cm(STYLE_CONFIG["margins"]["top_cm"])
    section.bottom_margin = Cm(STYLE_CONFIG["margins"]["bottom_cm"])
    section.left_margin = Cm(STYLE_CONFIG["margins"]["left_cm"])
    section.right_margin = Cm(STYLE_CONFIG["margins"]["right_cm"])


def add_cover_page(doc, title, subtitle_lines=None):
    """添加封面页"""
    for _ in range(6):
        doc.add_paragraph()
    add_styled_paragraph(doc, title, font_size=STYLE_CONFIG["fonts"]["cover_title"],
                         bold=True, color=STYLE_CONFIG["colors"]["primary"],
                         alignment=WD_ALIGN_PARAGRAPH.CENTER)
    if subtitle_lines:
        doc.add_paragraph()
        for line in subtitle_lines:
            add_styled_paragraph(doc, line, font_size=STYLE_CONFIG["fonts"]["cover_subtitle"],
                                 color=STYLE_CONFIG["colors"]["secondary"],
                                 alignment=WD_ALIGN_PARAGRAPH.CENTER)
    doc.add_page_break()


def add_toc_page(doc):
    """添加目录占位页"""
    add_styled_paragraph(doc, "目  录", font_size=STYLE_CONFIG["fonts"]["h1"],
                         bold=True, alignment=WD_ALIGN_PARAGRAPH.CENTER)
    doc.add_paragraph()
    add_styled_paragraph(doc, "（请在Word中右键 → 更新域 → 更新整个目录）",
                         font_size=STYLE_CONFIG["fonts"]["body"],
                         color=STYLE_CONFIG["colors"]["light_text"],
                         alignment=WD_ALIGN_PARAGRAPH.CENTER)
    doc.add_page_break()


def add_info_table(doc, data_pairs, cols=4):
    """添加信息表格（如员工基本信息）"""
    rows_needed = (len(data_pairs) + cols // 2 - 1) // (cols // 2)
    table = doc.add_table(rows=rows_needed, cols=cols)
    table.style = 'Table Grid'
    idx = 0
    for r in range(rows_needed):
        for c in range(0, cols, 2):
            if idx < len(data_pairs):
                label, value = data_pairs[idx]
                cell_label = table.rows[r].cells[c]
                cell_value = table.rows[r].cells[c + 1]
                # Label
                cell_label.text = ""
                p = cell_label.paragraphs[0]
                run = p.add_run(label)
                run.font.size = Pt(STYLE_CONFIG["fonts"]["table_body"])
                run.font.name = "微软雅黑"
                run._element.rPr.rFonts.set(qn('w:eastAsia'), "微软雅黑")
                run.font.bold = True
                set_cell_shading(cell_label, "F0F4FF")
                # Value
                cell_value.text = ""
                p2 = cell_value.paragraphs[0]
                run2 = p2.add_run(safe_str(value))
                run2.font.size = Pt(STYLE_CONFIG["fonts"]["table_body"])
                run2.font.name = "微软雅黑"
                run2._element.rPr.rFonts.set(qn('w:eastAsia'), "微软雅黑")
                idx += 1
    doc.add_paragraph()


def add_table_header_row(table, headers):
    """添加表格表头行"""
    for i, h in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = ""
        p = cell.paragraphs[0]
        run = p.add_run(h)
        run.font.bold = True
        run.font.size = Pt(STYLE_CONFIG["fonts"]["table_header"])
        run.font.name = "微软雅黑"
        run._element.rPr.rFonts.set(qn('w:eastAsia'), "微软雅黑")
        run.font.color.rgb = RGBColor.from_string("FFFFFF")
        set_cell_shading(cell, "1A56DB")


def add_table_data_row(table, values):
    """添加表格数据行"""
    row = table.add_row()
    for j, val in enumerate(values):
        cell = row.cells[j]
        cell.text = ""
        p = cell.paragraphs[0]
        run = p.add_run(safe_str(val))
        run.font.size = Pt(STYLE_CONFIG["fonts"]["table_body"])
        run.font.name = "微软雅黑"
        run._element.rPr.rFonts.set(qn('w:eastAsia'), "微软雅黑")
    return row


def add_sign_table(doc, rows_data=None):
    """添加签字确认表格"""
    if rows_data is None:
        rows_data = [
            ["员工签字", "", "日期", ""],
            ["主管签字", "", "日期", ""],
            ["部门负责人签字", "", "日期", ""],
        ]
    sign_table = doc.add_table(rows=len(rows_data), cols=4)
    sign_table.style = 'Table Grid'
    for i, row_data in enumerate(rows_data):
        for j, val in enumerate(row_data):
            cell = sign_table.rows[i].cells[j]
            cell.text = ""
            p = cell.paragraphs[0]
            run = p.add_run(val)
            run.font.size = Pt(STYLE_CONFIG["fonts"]["table_body"])
            run.font.name = "微软雅黑"
            run._element.rPr.rFonts.set(qn('w:eastAsia'), "微软雅黑")
            if j % 2 == 0:
                run.font.bold = True
                set_cell_shading(cell, "F0F4FF")
    doc.add_paragraph()


def add_bullet_list(doc, items, prefix="  •", color=None, icon=None):
    """添加项目符号列表"""
    for item in items:
        text = f"{prefix} {item}" if not icon else f"  {icon} {item}"
        add_styled_paragraph(doc, text,
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             color=color,
                             space_after=Pt(2))


# ==================== KPI目标书导出 ====================

def export_kpi_target(data, output_path):
    """导出KPI绩效目标书（完整版）"""
    doc = Document()
    setup_page_style(doc)
    d = data.get("data", data)

    # 兼容多种数据结构
    emp = d.get("employee", {})
    emp_name = safe_get(d, "employee_name", "name") or safe_get(emp, "name", default="")
    emp_id = safe_get(d, "employee_id", "id") or safe_get(emp, "id", "employee_id", default="")
    dept = safe_get(d, "department", "dept") or safe_get(emp, "department", default="")
    position = safe_get(d, "position", "role") or safe_get(emp, "position", default="")
    job_level = safe_get(d, "job_level", "level") or safe_get(emp, "level", "job_level", default="")
    hire_date = safe_get(d, "hire_date", default="")
    supervisor = safe_get(d, "supervisor", "manager") or safe_get(emp, "manager", "supervisor", default="")
    period = safe_get(d, "period", default="")
    create_date = safe_get(d, "create_date", default="")

    # 封面
    title = safe_get(d, "doc_title", default="KPI绩效目标书")
    subtitle_lines = [
        f"员工：{emp_name}",
        f"考核周期：{period}",
        f"制定日期：{create_date}",
    ]
    add_cover_page(doc, title, subtitle_lines)

    # 目录
    add_toc_page(doc)

    # 一、基本信息
    doc.add_heading("一、基本信息", level=1)
    info_pairs = [
        ("姓名", emp_name),
        ("工号", emp_id),
        ("部门", dept),
        ("岗位", position),
        ("职级", job_level),
        ("入职日期", hire_date),
        ("直属主管", supervisor),
        ("考核周期", period),
    ]
    add_info_table(doc, info_pairs)

    # 二、组织目标上下文
    org_context = safe_get(d, "org_context", "org_objective", "organization_context", default="")
    if org_context:
        doc.add_heading("二、组织目标上下文", level=1)
        add_styled_paragraph(doc, org_context, font_size=STYLE_CONFIG["fonts"]["body"])

    # 三、KPI指标明细
    kpis = d.get("kpis", []) or d.get("kpi_items", []) or d.get("indicators", [])
    if kpis:
        doc.add_heading("三、KPI指标明细", level=1)

        # 3.1 KPI汇总表
        doc.add_heading("3.1 KPI指标汇总", level=2)
        table = doc.add_table(rows=1, cols=7)
        table.style = 'Table Grid'
        add_table_header_row(table, ["序号", "KPI指标", "权重", "目标值", "衡量标准", "数据来源", "截止日期"])
        total_weight = 0
        for idx, kpi in enumerate(kpis, 1):
            weight = kpi.get("weight", 0)
            total_weight += weight
            values = [
                str(idx),
                safe_get(kpi, "name", "kpi_name", "indicator", default="-"),
                f"{weight}%",
                safe_get(kpi, "target_value", "target", default="-"),
                safe_get(kpi, "measurement", "measure", "measure_standard", default="-"),
                safe_get(kpi, "data_source", "source", default="-"),
                safe_get(kpi, "deadline", "due_date", default="-"),
            ]
            add_table_data_row(table, values)

        # 权重合计
        weight_color = STYLE_CONFIG["colors"]["success"] if total_weight == 100 else STYLE_CONFIG["colors"]["danger"]
        add_styled_paragraph(doc, f"权重合计：{total_weight}%",
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             bold=True, color=weight_color)

        # 3.2 各KPI详细说明
        doc.add_heading("3.2 各KPI详细说明", level=2)
        for idx, kpi in enumerate(kpis, 1):
            kpi_name = safe_get(kpi, "name", "kpi_name", "indicator", default=f"KPI-{idx}")
            doc.add_heading(f"KPI-{idx}：{kpi_name}", level=3)

            detail_pairs = [
                ("权重", f"{kpi.get('weight', 0)}%"),
                ("目标值", safe_get(kpi, "target_value", "target", default="-")),
                ("基线值", safe_get(kpi, "baseline", "baseline_value", "current_value", default="-")),
                ("衡量标准", safe_get(kpi, "measurement", "measure", default="-")),
                ("数据来源", safe_get(kpi, "data_source", "source", default="-")),
                ("截止日期", safe_get(kpi, "deadline", "due_date", default="-")),
            ]
            # 行动计划
            action_plan = safe_get(kpi, "action_plan", "actions", default="")
            if action_plan:
                detail_pairs.append(("行动计划", action_plan))

            # 风险与应对
            risks = safe_get(kpi, "risks", "risk", default="")
            if risks:
                detail_pairs.append(("风险与应对", risks))

            add_info_table(doc, detail_pairs, cols=2)

    # 四、行为/能力指标
    behavior_indicators = d.get("behavior_indicators", []) or d.get("behavioral_indicators", []) or d.get("behavior_items", [])
    if behavior_indicators:
        doc.add_heading("四、行为/能力指标", level=1)
        table = doc.add_table(rows=1, cols=4)
        table.style = 'Table Grid'
        add_table_header_row(table, ["行为/能力指标", "权重", "评分标准", "描述"])
        for bi in behavior_indicators:
            values = [
                safe_get(bi, "name", "indicator", default="-"),
                f"{bi.get('weight', 0)}%",
                safe_get(bi, "scoring_criteria", "criteria", "standard", default="-"),
                safe_get(bi, "description", "desc", default="-"),
            ]
            add_table_data_row(table, values)

    # 五、加分项与否决项
    bonus_items = d.get("bonus_items", []) or d.get("bonus", [])
    veto_items = d.get("veto_items", []) or d.get("veto", [])
    if bonus_items or veto_items:
        doc.add_heading("五、加分项与否决项", level=1)
        if bonus_items:
            add_styled_paragraph(doc, "加分项：", font_size=STYLE_CONFIG["fonts"]["body"],
                                 bold=True, color=STYLE_CONFIG["colors"]["success"])
            for item in bonus_items:
                add_styled_paragraph(doc, f"  ✅ {item}", font_size=STYLE_CONFIG["fonts"]["body"],
                                     color=STYLE_CONFIG["colors"]["success"], space_after=Pt(2))
        if veto_items:
            add_styled_paragraph(doc, "否决项：", font_size=STYLE_CONFIG["fonts"]["body"],
                                 bold=True, color=STYLE_CONFIG["colors"]["danger"])
            for item in veto_items:
                add_styled_paragraph(doc, f"  ❌ {item}", font_size=STYLE_CONFIG["fonts"]["body"],
                                     color=STYLE_CONFIG["colors"]["danger"], space_after=Pt(2))

    # 六、目标确认与签字
    doc.add_heading("六、目标确认与签字", level=1)
    add_styled_paragraph(doc, "本人已充分了解上述绩效目标的内容和要求，承诺按计划推进并达成目标。",
                         font_size=STYLE_CONFIG["fonts"]["body"],
                         space_before=Pt(8))
    add_sign_table(doc)

    doc.save(output_path)
    return output_path


# ==================== OKR目标书导出 ====================

def export_okr_target(data, output_path):
    """导出OKR绩效目标书（完整版）"""
    doc = Document()
    setup_page_style(doc)
    d = data.get("data", data)

    # 兼容多种数据结构
    emp = d.get("employee", {})
    emp_name = safe_get(d, "employee_name", "name") or safe_get(emp, "name", default="")
    emp_id = safe_get(d, "employee_id", "id") or safe_get(emp, "id", "employee_id", default="")
    dept = safe_get(d, "department", "dept") or safe_get(emp, "department", default="")
    position = safe_get(d, "position", "role") or safe_get(emp, "position", default="")
    job_level = safe_get(d, "job_level", "level") or safe_get(emp, "level", "job_level", "level", default="")
    supervisor = safe_get(d, "supervisor", "manager") or safe_get(emp, "manager", "supervisor", default="")
    period_info = d.get("period", {})
    period = safe_get(d, "period", default="") if isinstance(d.get("period"), str) else safe_get(period_info, "cycle", default="")
    create_date = safe_get(d, "create_date", default="")
    focus = safe_get(emp, "focus", default="")

    # 封面
    title = safe_get(d, "doc_title", default="OKR绩效目标书")
    subtitle_lines = [
        f"员工：{emp_name}",
        f"考核周期：{period}",
        f"制定日期：{create_date}",
    ]
    add_cover_page(doc, title, subtitle_lines)

    # 目录
    add_toc_page(doc)

    # 一、基本信息
    doc.add_heading("一、基本信息", level=1)
    info_pairs = [
        ("姓名", emp_name),
        ("工号", emp_id),
        ("部门", dept),
        ("岗位", position),
        ("职级", job_level),
        ("直属主管", supervisor),
        ("考核周期", period),
        ("重点方向", focus),
    ]
    # 过滤空值
    info_pairs = [(k, v) for k, v in info_pairs if v and v != "-"]
    add_info_table(doc, info_pairs)

    # 二、组织OKR上下文
    org_okr = safe_get(d, "org_okr", "org_context", "organization_okr", default="")
    if org_okr:
        doc.add_heading("二、组织OKR上下文", level=1)
        add_styled_paragraph(doc, org_okr, font_size=STYLE_CONFIG["fonts"]["body"])

    # 三、个人OKR — 兼容 objectives[] 和 okrs[] 两种结构
    objectives = d.get("objectives", []) or d.get("okrs", []) or d.get("okr_items", [])

    if objectives:
        doc.add_heading("三、个人OKR", level=1)

        # 3.1 OKR总览汇总表
        doc.add_heading("3.1 OKR总览", level=2)
        summary_table = doc.add_table(rows=1, cols=3)
        summary_table.style = 'Table Grid'
        add_table_header_row(summary_table, ["Objective", "KR数量", "对齐声明"])

        for obj in objectives:
            obj_title = safe_get(obj, "objective", "title", "name", default="-")
            krs = obj.get("key_results", []) or obj.get("krs", []) or obj.get("key_result", [])
            alignment = safe_get(obj, "alignment", "align", "alignment_note", default="-")
            add_table_data_row(summary_table, [obj_title, str(len(krs)), alignment])

        doc.add_paragraph()

        # 3.2 各Objective详细展开
        doc.add_heading("3.2 各Objective详细展开", level=2)
        for idx, obj in enumerate(objectives, 1):
            obj_id = safe_get(obj, "id", default=f"O{idx}")
            obj_title = safe_get(obj, "objective", "title", "name", default=f"Objective {idx}")
            obj_desc = safe_get(obj, "description", "desc", default="")
            alignment = safe_get(obj, "alignment", "align", "alignment_note", default="")

            doc.add_heading(f"{obj_id}：{obj_title}", level=3)

            if obj_desc:
                add_styled_paragraph(doc, f"目标说明：{obj_desc}",
                                     font_size=STYLE_CONFIG["fonts"]["body"],
                                     color=STYLE_CONFIG["colors"]["secondary"])
            if alignment:
                add_styled_paragraph(doc, f"对齐声明：{alignment}",
                                     font_size=STYLE_CONFIG["fonts"]["body"],
                                     color=STYLE_CONFIG["colors"]["primary"],
                                     italic=True)

            # KR明细表
            krs = obj.get("key_results", []) or obj.get("krs", []) or obj.get("key_result", [])
            if krs:
                kr_table = doc.add_table(rows=1, cols=7)
                kr_table.style = 'Table Grid'
                add_table_header_row(kr_table, ["KR", "权重", "信心指数", "基线", "目标值", "衡量方式", "对齐声明"])

                for kr_idx, kr in enumerate(krs, 1):
                    # 兼容多种字段命名
                    kr_text = safe_get(kr, "kr", "key_result", "name", "title", default=f"KR{kr_idx}")
                    weight = safe_get(kr, "weight", default="-")
                    confidence = safe_get(kr, "confidence", default="-")
                    baseline = safe_get(kr, "baseline", "baseline_value", "current_value", default="-")
                    target = safe_get(kr, "target", "target_value", default="-")
                    measure = safe_get(kr, "measure", "measurement", "measure_standard", default="-")
                    kr_alignment = safe_get(kr, "alignment", "align", default="-")

                    values = [kr_text, weight, confidence, baseline, target, measure, kr_alignment]
                    add_table_data_row(kr_table, values)

                # 每个O的KR权重汇总
                kr_weights = []
                for kr in krs:
                    w = safe_get(kr, "weight", default="0")
                    try:
                        kr_weights.append(float(str(w).replace('%', '')))
                    except:
                        pass
                if kr_weights:
                    total_w = sum(kr_weights)
                    w_color = STYLE_CONFIG["colors"]["success"] if abs(total_w - 100) < 1 else STYLE_CONFIG["colors"]["warning"]
                    add_styled_paragraph(doc, f"KR权重合计：{total_w:.0f}%",
                                         font_size=STYLE_CONFIG["fonts"]["small"],
                                         bold=True, color=w_color, space_after=Pt(8))

            doc.add_paragraph()

    # 四、职业能力目标
    competency_goals = d.get("competency_goals", []) or d.get("capability_goals", []) or d.get("ability_goals", [])
    if competency_goals:
        doc.add_heading("四、职业能力目标", level=1)
        add_styled_paragraph(doc, "（占总分10分）", font_size=STYLE_CONFIG["fonts"]["small"],
                             color=STYLE_CONFIG["colors"]["light_text"])
        table = doc.add_table(rows=1, cols=4)
        table.style = 'Table Grid'
        add_table_header_row(table, ["能力维度", "目标描述", "衡量标准", "目标分"])
        for cg in competency_goals:
            values = [
                safe_get(cg, "dimension", "name", default="-"),
                safe_get(cg, "description", "desc", "target_description", default="-"),
                safe_get(cg, "measure", "measurement", default="-"),
                safe_get(cg, "target_score", "score", default="-"),
            ]
            add_table_data_row(table, values)
        doc.add_paragraph()

    # 五、行为准则目标
    behavioral_goals = d.get("behavioral_goals", []) or d.get("behavior_goals", []) or d.get("behavior_items", [])
    if behavioral_goals:
        doc.add_heading("五、行为准则目标", level=1)
        add_styled_paragraph(doc, "（占总分10分）", font_size=STYLE_CONFIG["fonts"]["small"],
                             color=STYLE_CONFIG["colors"]["light_text"])
        table = doc.add_table(rows=1, cols=3)
        table.style = 'Table Grid'
        add_table_header_row(table, ["行为准则", "衡量标准", "目标"])
        for bg in behavioral_goals:
            values = [
                safe_get(bg, "item", "name", "behavior", default="-"),
                safe_get(bg, "measure", "measurement", default="-"),
                safe_get(bg, "target", "target_value", default="-"),
            ]
            add_table_data_row(table, values)
        doc.add_paragraph()

    # 六、发展计划
    development_plan = safe_get(d, "development_plan", "development", default="")
    if development_plan:
        doc.add_heading("六、发展计划", level=1)
        add_styled_paragraph(doc, development_plan, font_size=STYLE_CONFIG["fonts"]["body"])

    # 七、签字确认
    doc.add_heading("七、签字确认", level=1)
    add_styled_paragraph(doc, "本人已充分了解上述OKR目标的内容和要求，承诺按计划推进并达成目标。",
                         font_size=STYLE_CONFIG["fonts"]["body"],
                         space_before=Pt(8))
    sig_data = d.get("signatures", {})
    sign_rows = [
        ["员工签字", safe_get(sig_data, "employee", default=""), "日期", ""],
        ["主管签字", safe_get(sig_data, "manager", default=""), "日期", ""],
    ]
    add_sign_table(doc, sign_rows)

    doc.save(output_path)
    return output_path


# ==================== 绩效跟踪报告导出 ====================

def export_progress_report(data, output_path):
    """导出绩效进度跟踪报告（完整版）"""
    doc = Document()
    setup_page_style(doc)
    d = data.get("data", data)

    emp = d.get("employee", {})
    emp_name = safe_get(d, "employee_name", "name") or safe_get(emp, "name", default="")
    dept = safe_get(d, "department", "dept") or safe_get(emp, "department", default="")
    position = safe_get(d, "position", "role") or safe_get(emp, "position", default="")
    supervisor = safe_get(d, "supervisor", "manager") or safe_get(emp, "manager", "supervisor", default="")
    period = safe_get(d, "period", default="")
    report_date = safe_get(d, "report_date", default="")
    mode = safe_get(d, "mode", "type", default="KPI")

    # 封面
    title = safe_get(d, "doc_title", default="绩效进度跟踪报告")
    subtitle_lines = [
        f"员工：{emp_name}",
        f"跟踪周期：{period}",
        f"报告日期：{report_date}",
    ]
    add_cover_page(doc, title, subtitle_lines)
    add_toc_page(doc)

    # 一、基本信息
    doc.add_heading("一、基本信息", level=1)
    info_pairs = [
        ("姓名", emp_name),
        ("部门", dept),
        ("岗位", position),
        ("主管", supervisor),
        ("跟踪周期", period),
        ("报告日期", report_date),
        ("考核模式", mode),
    ]
    info_pairs = [(k, v) for k, v in info_pairs if v and v != "-"]
    add_info_table(doc, info_pairs)

    # 二、目标进度总览
    targets = d.get("targets", []) or d.get("target_items", []) or d.get("progress_items", [])
    if targets:
        doc.add_heading("二、目标进度总览", level=1)
        table = doc.add_table(rows=1, cols=7)
        table.style = 'Table Grid'
        add_table_header_row(table, ["目标/指标", "权重", "目标值", "当前值", "完成率", "状态", "趋势"])
        for t in targets:
            completion = t.get("completion_rate", 0) or t.get("progress", 0)
            status = safe_get(t, "status", default="")
            if not status:
                if completion >= 80:
                    status = "🟢 正常"
                elif completion >= 50:
                    status = "🟡 需关注"
                else:
                    status = "🔴 滞后"
            trend = safe_get(t, "trend", default="-")
            values = [
                safe_get(t, "name", "target", "indicator", default="-"),
                f"{t.get('weight', 0)}%",
                safe_str(t.get("target_value", "")),
                safe_str(t.get("current_value", "")),
                f"{completion}%",
                status,
                trend,
            ]
            row = add_table_data_row(table, values)
            # 状态列着色
            status_cell = row.cells[5]
            for p in status_cell.paragraphs:
                for run in p.runs:
                    if "正常" in str(run.text):
                        run.font.color.rgb = RGBColor.from_string(STYLE_CONFIG["colors"]["success"])
                    elif "需关注" in str(run.text):
                        run.font.color.rgb = RGBColor.from_string(STYLE_CONFIG["colors"]["warning"])
                    elif "滞后" in str(run.text):
                        run.font.color.rgb = RGBColor.from_string(STYLE_CONFIG["colors"]["danger"])

    # 三、关键亮点
    highlights = d.get("highlights", []) or d.get("achievements", [])
    if highlights:
        doc.add_heading("三、关键亮点", level=1)
        for h in highlights:
            add_styled_paragraph(doc, f"  ✅ {h}",
                                 font_size=STYLE_CONFIG["fonts"]["body"],
                                 color=STYLE_CONFIG["colors"]["success"],
                                 space_after=Pt(2))

    # 四、风险与问题
    risks = d.get("risks", []) or d.get("risk_items", [])
    if risks:
        doc.add_heading("四、风险与问题", level=1)
        for r in risks:
            level = safe_get(r, "level", "severity", default="中")
            color_map = {"高": STYLE_CONFIG["colors"]["danger"], "中": STYLE_CONFIG["colors"]["warning"], "低": STYLE_CONFIG["colors"]["accent"]}
            add_styled_paragraph(doc, f"  ⚠ [{level}] {safe_get(r, 'description', 'desc', default='')}",
                                 font_size=STYLE_CONFIG["fonts"]["body"],
                                 color=color_map.get(level, STYLE_CONFIG["colors"]["accent"]),
                                 space_after=Pt(2))
            mitigation = safe_get(r, "mitigation", "action", "countermeasure", default="")
            if mitigation:
                add_styled_paragraph(doc, f"      应对措施：{mitigation}",
                                     font_size=STYLE_CONFIG["fonts"]["body"],
                                     color=STYLE_CONFIG["colors"]["light_text"],
                                     space_after=Pt(4))

    # 五、关键事件记录
    events = d.get("key_events", []) or d.get("events", [])
    if events:
        doc.add_heading("五、关键事件记录", level=1)
        table = doc.add_table(rows=1, cols=4)
        table.style = 'Table Grid'
        add_table_header_row(table, ["日期", "类型", "事件描述", "影响评估"])
        for e in events:
            values = [
                safe_get(e, "date", default="-"),
                safe_get(e, "type", "event_type", default="-"),
                safe_get(e, "description", "desc", default="-"),
                safe_get(e, "impact", "assessment", default="-"),
            ]
            add_table_data_row(table, values)

    # 六、主管评语
    supervisor_comment = safe_get(d, "supervisor_comment", "manager_comment", default="")
    if supervisor_comment:
        doc.add_heading("六、主管评语", level=1)
        add_styled_paragraph(doc, supervisor_comment, font_size=STYLE_CONFIG["fonts"]["body"])

    # 七、员工自评
    self_evaluation = safe_get(d, "self_evaluation", "employee_comment", default="")
    if self_evaluation:
        doc.add_heading("七、员工自评", level=1)
        add_styled_paragraph(doc, self_evaluation, font_size=STYLE_CONFIG["fonts"]["body"])

    # 八、下一步计划
    next_steps = d.get("next_steps", []) or d.get("action_items", [])
    if next_steps:
        doc.add_heading("八、下一步计划", level=1)
        for step in next_steps:
            add_styled_paragraph(doc, f"  • {step}",
                                 font_size=STYLE_CONFIG["fonts"]["body"],
                                 space_after=Pt(2))

    doc.save(output_path)
    return output_path


# ==================== 绩效评估报告导出 ====================

def export_evaluation_report(data, output_path):
    """导出绩效评估报告（完整版）"""
    doc = Document()
    setup_page_style(doc)
    d = data.get("data", data)

    emp = d.get("employee", {})
    emp_name = safe_get(d, "employee_name", "name") or safe_get(emp, "name", default="")
    emp_id = safe_get(d, "employee_id", "id") or safe_get(emp, "id", default="")
    dept = safe_get(d, "department", "dept") or safe_get(emp, "department", default="")
    position = safe_get(d, "position", "role") or safe_get(emp, "position", default="")
    job_level = safe_get(d, "job_level", "level") or safe_get(emp, "level", default="")
    supervisor = safe_get(d, "supervisor", "manager") or safe_get(emp, "manager", "supervisor", default="")
    period = safe_get(d, "period", default="")
    evaluation_date = safe_get(d, "evaluation_date", default="")
    overall_rating = safe_get(d, "overall_rating", "rating", default="")

    # 封面
    title = safe_get(d, "doc_title", default="绩效评估报告")
    subtitle_lines = [
        f"员工：{emp_name}",
        f"考核周期：{period}",
        f"评估日期：{evaluation_date}",
        f"综合评级：{overall_rating}",
    ]
    add_cover_page(doc, title, subtitle_lines)
    add_toc_page(doc)

    # 一、基本信息
    doc.add_heading("一、基本信息", level=1)
    info_pairs = [
        ("姓名", emp_name),
        ("工号", emp_id),
        ("部门", dept),
        ("岗位", position),
        ("职级", job_level),
        ("考核周期", period),
        ("直属主管", supervisor),
        ("评估日期", evaluation_date),
    ]
    add_info_table(doc, info_pairs)

    # 二、业绩指标评估
    performance_items = d.get("performance_items", []) or d.get("kpi_items", []) or d.get("indicators", [])
    if performance_items:
        doc.add_heading("二、业绩指标评估", level=1)

        # 2.1 汇总表
        table = doc.add_table(rows=1, cols=7)
        table.style = 'Table Grid'
        add_table_header_row(table, ["指标", "权重", "目标值", "实际值", "完成率", "得分", "评语"])
        weighted_score = 0
        for item in performance_items:
            score = item.get("score", 0)
            weight = item.get("weight", 0)
            weighted_score += weight * score / 100
            values = [
                safe_get(item, "name", "indicator", default="-"),
                f"{weight}%",
                safe_str(item.get("target_value", "")),
                safe_str(item.get("actual_value", "")),
                f"{item.get('completion_rate', 0)}%",
                str(score),
                safe_get(item, "comment", "remark", default="-"),
            ]
            add_table_data_row(table, values)

        add_styled_paragraph(doc, f"业绩加权得分：{weighted_score:.1f}分",
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             bold=True, color=STYLE_CONFIG["colors"]["primary"],
                             space_before=Pt(8))

        # 2.2 各指标详细评述
        doc.add_heading("2.2 各指标详细评述", level=2)
        for item in performance_items:
            name = safe_get(item, "name", "indicator", default="")
            doc.add_heading(f"  {name}", level=3)
            detail_pairs = [
                ("权重", f"{item.get('weight', 0)}%"),
                ("目标值", safe_str(item.get("target_value", ""))),
                ("实际值", safe_str(item.get("actual_value", ""))),
                ("完成率", f"{item.get('completion_rate', 0)}%"),
                ("得分", str(item.get("score", ""))),
                ("评语", safe_get(item, "comment", "remark", default="-")),
            ]
            evidence = safe_get(item, "evidence", "data_point", default="")
            if evidence:
                detail_pairs.append(("事实依据", evidence))
            add_info_table(doc, detail_pairs, cols=2)

    # 三、能力评估
    competency_items = d.get("competency_items", []) or d.get("competency", []) or d.get("abilities", [])
    if competency_items:
        doc.add_heading("三、能力评估", level=1)
        table = doc.add_table(rows=1, cols=5)
        table.style = 'Table Grid'
        add_table_header_row(table, ["能力维度", "权重", "目标分", "实际评分", "评语"])
        for item in competency_items:
            values = [
                safe_get(item, "name", "dimension", default="-"),
                f"{item.get('weight', 0)}%",
                safe_get(item, "target_score", "target", default="-"),
                str(item.get("score", "")),
                safe_get(item, "comment", "remark", default="-"),
            ]
            add_table_data_row(table, values)

        # 能力加权总分
        competency_weighted = sum(item.get("weight", 0) * item.get("score", 0) / 100 for item in competency_items)
        add_styled_paragraph(doc, f"能力加权得分：{competency_weighted:.1f}分",
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             bold=True, color=STYLE_CONFIG["colors"]["primary"],
                             space_before=Pt(8))

    # 四、综合评级
    doc.add_heading("四、综合评级", level=1)
    rating = safe_get(d, "overall_rating", "rating", default="")

    # 评级标准对照表
    rating_table = doc.add_table(rows=7, cols=3)
    rating_table.style = 'Table Grid'
    add_table_header_row(rating_table, ["评级", "含义", "比例参考"])
    rating_levels = [
        ("S - 卓越", "远超目标，产出和质量均为团队标杆", "≤5%"),
        ("A - 优秀", "超出目标，有突出贡献或创新", "15-20%"),
        ("B+ - 良好", "完全达成目标，部分超出预期", "25-30%"),
        ("B - 合格", "基本达成目标，符合岗位要求", "30-35%"),
        ("C - 待改进", "部分目标未达成，需要明显改进", "10-15%"),
        ("D - 不合格", "主要目标未达成，需要绩效改进计划", "≤5%"),
    ]
    for level, desc, proportion in rating_levels:
        row = rating_table.add_row()
        values = [level, desc, proportion]
        for j, val in enumerate(values):
            cell = row.cells[j]
            cell.text = ""
            p = cell.paragraphs[0]
            run = p.add_run(val)
            run.font.size = Pt(STYLE_CONFIG["fonts"]["table_body"])
            run.font.name = "微软雅黑"
            run._element.rPr.rFonts.set(qn('w:eastAsia'), "微软雅黑")
            if j == 0:
                run.font.bold = True
        # 高亮当前评级
        if rating and level.startswith(rating):
            for j in range(3):
                set_cell_shading(row.cells[j], "F0F4FF")
            row.cells[0].paragraphs[0].runs[0].font.color.rgb = RGBColor.from_string(STYLE_CONFIG["colors"]["primary"])

    rating_justification = safe_get(d, "rating_justification", "justification", default="")
    if rating_justification:
        add_styled_paragraph(doc, f"评级说明：{rating_justification}",
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             space_before=Pt(8))

    # 五、优势与待改进
    strengths = d.get("strengths", []) or d.get("advantages", [])
    improvements = d.get("improvements", []) or d.get("weaknesses", [])
    if strengths or improvements:
        doc.add_heading("五、优势与待改进", level=1)
        if strengths:
            add_styled_paragraph(doc, "优势：", font_size=STYLE_CONFIG["fonts"]["h3"],
                                 bold=True, color=STYLE_CONFIG["colors"]["success"])
            for s in strengths:
                add_styled_paragraph(doc, f"  ✅ {s}",
                                     font_size=STYLE_CONFIG["fonts"]["body"],
                                     color=STYLE_CONFIG["colors"]["success"],
                                     space_after=Pt(2))
        if improvements:
            add_styled_paragraph(doc, "待改进：", font_size=STYLE_CONFIG["fonts"]["h3"],
                                 bold=True, color=STYLE_CONFIG["colors"]["danger"])
            for imp in improvements:
                add_styled_paragraph(doc, f"  ⚠ {imp}",
                                     font_size=STYLE_CONFIG["fonts"]["body"],
                                     color=STYLE_CONFIG["colors"]["danger"],
                                     space_after=Pt(2))

    # 六、发展建议
    development = d.get("development_suggestions", []) or d.get("suggestions", []) or d.get("development", [])
    if development:
        doc.add_heading("六、发展建议", level=1)
        for dev in development:
            add_styled_paragraph(doc, f"  • {dev}",
                                 font_size=STYLE_CONFIG["fonts"]["body"],
                                 space_after=Pt(2))

    # 七、员工自评摘要
    self_eval = safe_get(d, "self_evaluation", "employee_self_rating", default="")
    if self_eval:
        doc.add_heading("七、员工自评摘要", level=1)
        add_styled_paragraph(doc, self_eval, font_size=STYLE_CONFIG["fonts"]["body"])

    # 八、主管综合评语
    mgr_comment = safe_get(d, "supervisor_comment", "manager_comment", default="")
    if mgr_comment:
        doc.add_heading("八、主管综合评语", level=1)
        add_styled_paragraph(doc, mgr_comment, font_size=STYLE_CONFIG["fonts"]["body"])

    # 九、签字确认
    doc.add_heading("九、签字确认", level=1)
    add_sign_table(doc, [
        ["员工签字", "", "日期", ""],
        ["主管签字", "", "日期", ""],
        ["HR确认", "", "日期", ""],
    ])

    doc.save(output_path)
    return output_path


# ==================== 绩效面谈提纲导出 ====================

def export_interview_guide(data, output_path):
    """导出绩效面谈提纲（完整版）"""
    doc = Document()
    setup_page_style(doc)
    d = data.get("data", data)

    emp = d.get("employee", {})
    emp_name = safe_get(d, "employee_name", "name") or safe_get(emp, "name", default="")
    interview_type = safe_get(d, "interview_type", "type", default="定期绩效面谈")
    interview_date = safe_get(d, "interview_date", "date", default="")
    interviewer = safe_get(d, "interviewer", default="")

    # 封面
    title = safe_get(d, "doc_title", default="绩效面谈提纲")
    subtitle_lines = [
        f"员工：{emp_name}",
        f"面谈类型：{interview_type}",
        f"面谈日期：{interview_date}",
        f"面谈人：{interviewer}",
    ]
    add_cover_page(doc, title, subtitle_lines)
    add_toc_page(doc)

    # 一、面谈准备
    doc.add_heading("一、面谈准备", level=1)
    preparation = d.get("preparation", []) or d.get("prep_items", [])
    if preparation:
        add_styled_paragraph(doc, "面谈前需完成以下准备：", font_size=STYLE_CONFIG["fonts"]["body"],
                             bold=True, space_after=Pt(4))
        for prep in preparation:
            add_styled_paragraph(doc, f"  □ {prep}",
                                 font_size=STYLE_CONFIG["fonts"]["body"],
                                 space_after=Pt(2))

    # 面谈注意事项
    doc.add_heading("面谈注意事项", level=2)
    notes = [
        "选择私密空间，确保面谈不被打扰",
        "提前3天通知员工面谈时间和目的",
        "准备充分的绩效数据和事实依据",
        "保持开放心态，多倾听少评判",
        "使用SBI模型（情境→行为→影响）进行反馈",
    ]
    for note in notes:
        add_styled_paragraph(doc, f"  💡 {note}",
                             font_size=STYLE_CONFIG["fonts"]["small"],
                             color=STYLE_CONFIG["colors"]["light_text"],
                             space_after=Pt(2))

    # 二、开场暖场
    doc.add_heading("二、开场暖场（3-5分钟）", level=1)
    opening = safe_get(d, "opening_remarks", default="")
    if opening:
        add_styled_paragraph(doc, opening,
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             color=STYLE_CONFIG["colors"]["secondary"])
    add_styled_paragraph(doc, "参考话术：", font_size=STYLE_CONFIG["fonts"]["body"],
                         bold=True, space_before=Pt(8))
    opening_script = safe_get(d, "opening_script", default="感谢你抽时间来面谈。这次面谈的目的是一起回顾这段时间的工作表现，看看哪些做得好，哪些可以改进，一起商量接下来的发展方向。")
    add_styled_paragraph(doc, f'  "{opening_script}"',
                         font_size=STYLE_CONFIG["fonts"]["body"],
                         color=STYLE_CONFIG["colors"]["primary"])

    # 三、员工自评
    doc.add_heading("三、员工自评（5-10分钟）", level=1)
    self_eval_questions = d.get("self_evaluation_questions", []) or d.get("self_eval_prompts", [])
    if self_eval_questions:
        add_styled_paragraph(doc, "引导员工进行自我评价：", font_size=STYLE_CONFIG["fonts"]["body"],
                             bold=True, space_after=Pt(4))
        for q in self_eval_questions:
            add_styled_paragraph(doc, f"  ❓ {q}",
                                 font_size=STYLE_CONFIG["fonts"]["body"],
                                 space_after=Pt(2))
    else:
        default_questions = [
            "回顾这半年的工作，你觉得自己最满意的是什么？",
            "有哪些目标你觉得完成得不太理想？原因是什么？",
            "在工作中有哪些地方你觉得需要支持或资源？",
        ]
        add_styled_paragraph(doc, "引导员工进行自我评价：", font_size=STYLE_CONFIG["fonts"]["body"],
                             bold=True, space_after=Pt(4))
        for q in default_questions:
            add_styled_paragraph(doc, f"  ❓ {q}",
                                 font_size=STYLE_CONFIG["fonts"]["body"],
                                 space_after=Pt(2))

    # 员工自评记录（留空给面谈时填写）
    add_styled_paragraph(doc, "【员工自评记录】", font_size=STYLE_CONFIG["fonts"]["body"],
                         bold=True, space_before=Pt(8))
    for _ in range(3):
        add_styled_paragraph(doc, "", font_size=STYLE_CONFIG["fonts"]["body"], space_after=Pt(12))

    # 四、业绩回顾
    doc.add_heading("四、业绩回顾（10-15分钟）", level=1)

    # 4.1 亮点与成绩
    doc.add_heading("4.1 亮点与成绩", level=2)
    highlights = d.get("performance_highlights", []) or d.get("highlights", [])
    for h in highlights:
        add_styled_paragraph(doc, f"  ✅ {h}",
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             color=STYLE_CONFIG["colors"]["success"],
                             space_after=Pt(2))

    # 4.2 差距与不足
    doc.add_heading("4.2 差距与不足", level=2)
    gaps = d.get("performance_gaps", []) or d.get("gaps", [])
    for g in gaps:
        add_styled_paragraph(doc, f"  ⚠ {g}",
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             color=STYLE_CONFIG["colors"]["warning"],
                             space_after=Pt(2))

    # 4.3 KPI完成数据
    kpi_summary = d.get("kpi_summary", []) or d.get("performance_data", [])
    if kpi_summary:
        doc.add_heading("4.3 KPI完成数据", level=2)
        table = doc.add_table(rows=1, cols=5)
        table.style = 'Table Grid'
        add_table_header_row(table, ["指标", "目标值", "实际值", "完成率", "评价"])
        for kpi in kpi_summary:
            values = [
                safe_get(kpi, "name", default="-"),
                safe_str(kpi.get("target_value", "")),
                safe_str(kpi.get("actual_value", "")),
                f"{kpi.get('completion_rate', 0)}%",
                safe_get(kpi, "comment", default="-"),
            ]
            add_table_data_row(table, values)

    # 五、能力反馈
    doc.add_heading("五、能力反馈（5-10分钟）", level=1)
    competency_feedback = d.get("competency_feedback", []) or d.get("ability_feedback", [])
    if competency_feedback:
        table = doc.add_table(rows=1, cols=4)
        table.style = 'Table Grid'
        add_table_header_row(table, ["能力维度", "优势", "待提升", "建议行动"])
        for cf in competency_feedback:
            values = [
                safe_get(cf, "dimension", "name", default="-"),
                safe_get(cf, "strength", default="-"),
                safe_get(cf, "improvement", default="-"),
                safe_get(cf, "suggestion", "action", default="-"),
            ]
            add_table_data_row(table, values)

    # 六、改进计划与发展建议
    doc.add_heading("六、改进计划与发展建议（10分钟）", level=1)
    improvement_plan = d.get("improvement_plan", []) or d.get("action_plan", [])
    if improvement_plan:
        table = doc.add_table(rows=1, cols=5)
        table.style = 'Table Grid'
        add_table_header_row(table, ["改进项", "具体行动", "目标时间", "支持资源", "检查节点"])
        for plan in improvement_plan:
            values = [
                safe_get(plan, "item", "area", default="-"),
                safe_get(plan, "action", default="-"),
                safe_get(plan, "deadline", "target_date", default="-"),
                safe_get(plan, "support", "resource", default="-"),
                safe_get(plan, "check_point", "checkpoint", default="-"),
            ]
            add_table_data_row(table, values)

    # 七、职业发展讨论
    doc.add_heading("七、职业发展讨论（5分钟）", level=1)
    career_topics = d.get("career_topics", []) or d.get("career_questions", [])
    if career_topics:
        for topic in career_topics:
            add_styled_paragraph(doc, f"  • {topic}",
                                 font_size=STYLE_CONFIG["fonts"]["body"],
                                 space_after=Pt(2))
    else:
        default_topics = [
            "你对自己未来1-2年的职业发展有什么想法？",
            "有没有特别想深入的技术方向或想承担的项目？",
            "对于下一步发展，你认为需要在哪些方面加强？",
        ]
        for topic in default_topics:
            add_styled_paragraph(doc, f"  • {topic}",
                                 font_size=STYLE_CONFIG["fonts"]["body"],
                                 space_after=Pt(2))

    # 八、面谈结束确认
    doc.add_heading("八、面谈结束确认", level=1)
    closing_items = d.get("closing_items", []) or d.get("closing", [])
    if closing_items:
        for item in closing_items:
            add_styled_paragraph(doc, f"  □ {item}",
                                 font_size=STYLE_CONFIG["fonts"]["body"],
                                 space_after=Pt(2))
    else:
        default_closing = [
            "确认改进计划和目标",
            "确认下次检查时间",
            "确认所需的支持资源已到位",
            "员工对面谈内容无异议并签字",
        ]
        for item in default_closing:
            add_styled_paragraph(doc, f"  □ {item}",
                                 font_size=STYLE_CONFIG["fonts"]["body"],
                                 space_after=Pt(2))

    # 签字
    doc.add_paragraph()
    add_sign_table(doc, [
        ["员工签字", "", "日期", ""],
        ["主管签字", "", "日期", ""],
    ])

    doc.save(output_path)
    return output_path


# ==================== PIP改进计划导出 ====================

def export_pip_plan(data, output_path):
    """导出绩效改进计划（PIP）（完整版）"""
    doc = Document()
    setup_page_style(doc)
    d = data.get("data", data)

    emp = d.get("employee", {})
    emp_name = safe_get(d, "employee_name", "name") or safe_get(emp, "name", default="")
    emp_id = safe_get(d, "employee_id", "id") or safe_get(emp, "id", default="")
    dept = safe_get(d, "department", "dept") or safe_get(emp, "department", default="")
    position = safe_get(d, "position", "role") or safe_get(emp, "position", default="")
    supervisor = safe_get(d, "supervisor", "manager") or safe_get(emp, "manager", "supervisor", default="")
    hr_bp = safe_get(d, "hr_bp", "hr", default="")
    pip_period = safe_get(d, "period", "pip_period", default="")
    create_date = safe_get(d, "create_date", default="")
    current_rating = safe_get(d, "current_rating", "rating", default="")

    # 封面
    title = safe_get(d, "doc_title", default="绩效改进计划（PIP）")
    subtitle_lines = [
        f"员工：{emp_name}",
        f"改进周期：{pip_period}",
        f"制定日期：{create_date}",
        f"当前评级：{current_rating}",
    ]
    add_cover_page(doc, title, subtitle_lines)
    add_toc_page(doc)

    # 一、基本信息
    doc.add_heading("一、基本信息", level=1)
    info_pairs = [
        ("姓名", emp_name),
        ("工号", emp_id),
        ("部门", dept),
        ("岗位", position),
        ("主管", supervisor),
        ("HR BP", hr_bp),
        ("改进周期", pip_period),
        ("当前评级", current_rating),
        ("制定日期", create_date),
    ]
    info_pairs = [(k, v) for k, v in info_pairs if v and v != "-"]
    add_info_table(doc, info_pairs)

    # 二、问题诊断
    doc.add_heading("二、问题诊断", level=1)
    issues = d.get("issues", []) or d.get("problems", [])
    if issues:
        # 2.1 问题汇总
        doc.add_heading("2.1 问题汇总", level=2)
        table = doc.add_table(rows=1, cols=4)
        table.style = 'Table Grid'
        add_table_header_row(table, ["问题描述", "严重程度", "事实依据", "根因分析"])
        for issue in issues:
            values = [
                safe_get(issue, "description", "desc", "problem", default="-"),
                safe_get(issue, "level", "severity", default="中"),
                safe_get(issue, "evidence", "fact", default="-"),
                safe_get(issue, "root_cause", "cause", default="-"),
            ]
            row = add_table_data_row(table, values)
            # 严重程度着色
            severity = safe_get(issue, "level", "severity", default="中")
            severity_cell = row.cells[1]
            for p in severity_cell.paragraphs:
                for run in p.runs:
                    if severity == "高":
                        run.font.color.rgb = RGBColor.from_string(STYLE_CONFIG["colors"]["danger"])
                    elif severity == "中":
                        run.font.color.rgb = RGBColor.from_string(STYLE_CONFIG["colors"]["warning"])
                    run.font.bold = True

    # 三、改进目标
    doc.add_heading("三、改进目标", level=1)
    improvement_goals = d.get("improvement_goals", []) or d.get("goals", []) or d.get("targets", [])
    if improvement_goals:
        table = doc.add_table(rows=1, cols=6)
        table.style = 'Table Grid'
        add_table_header_row(table, ["改进项", "当前水平", "目标水平", "衡量标准", "达成期限", "权重"])
        for goal in improvement_goals:
            values = [
                safe_get(goal, "item", "name", "area", default="-"),
                safe_str(goal.get("current_level", "")),
                safe_str(goal.get("target_level", "")),
                safe_get(goal, "measurement", "measure", default="-"),
                safe_get(goal, "deadline", "due_date", default="-"),
                f"{goal.get('weight', 0)}%" if goal.get('weight', 0) else "-",
            ]
            add_table_data_row(table, values)

    # 四、支持措施
    doc.add_heading("四、支持措施", level=1)
    supports = d.get("support_measures", []) or d.get("supports", []) or d.get("resources", [])
    if supports:
        table = doc.add_table(rows=1, cols=4)
        table.style = 'Table Grid'
        add_table_header_row(table, ["支持类型", "具体内容", "责任人", "时间安排"])
        for s in supports:
            if isinstance(s, str):
                add_styled_paragraph(doc, f"  • {s}",
                                     font_size=STYLE_CONFIG["fonts"]["body"],
                                     space_after=Pt(2))
            else:
                values = [
                    safe_get(s, "type", default="通用"),
                    safe_get(s, "content", "description", default=str(s)),
                    safe_get(s, "responsible", "owner", default="-"),
                    safe_get(s, "timeline", "schedule", default="-"),
                ]
                add_table_data_row(table, values)

    # 五、检查节点
    doc.add_heading("五、检查节点", level=1)
    checkpoints = d.get("checkpoints", []) or d.get("reviews", [])
    if checkpoints:
        table = doc.add_table(rows=1, cols=5)
        table.style = 'Table Grid'
        add_table_header_row(table, ["检查日期", "检查内容", "评估标准", "评估人", "评估结果"])
        for cp in checkpoints:
            values = [
                safe_get(cp, "date", default="-"),
                safe_get(cp, "content", "topic", default="-"),
                safe_get(cp, "criteria", "standard", default="-"),
                safe_get(cp, "evaluator", "reviewer", default="-"),
                safe_get(cp, "result", "outcome", default="待评估"),
            ]
            add_table_data_row(table, values)

    # 六、员工态度与承诺
    doc.add_heading("六、员工态度与承诺", level=1)
    attitude = safe_get(d, "employee_attitude", "attitude", default="")
    commitment = safe_get(d, "employee_commitment", "commitment", default="")
    if attitude:
        add_styled_paragraph(doc, f"员工态度：{attitude}",
                             font_size=STYLE_CONFIG["fonts"]["body"])
    if commitment:
        add_styled_paragraph(doc, f"员工承诺：{commitment}",
                             font_size=STYLE_CONFIG["fonts"]["body"])
    if not attitude and not commitment:
        add_styled_paragraph(doc, "（面谈时记录员工对改进计划的态度和承诺）",
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             color=STYLE_CONFIG["colors"]["light_text"])

    # 七、结果预期
    doc.add_heading("七、结果预期", level=1)
    outcome_success = safe_get(d, "outcome_if_success", "success_outcome", default="")
    outcome_failure = safe_get(d, "outcome_if_failure", "failure_outcome", default="")
    if outcome_success:
        add_styled_paragraph(doc, f"  ✅ 达标结果：{outcome_success}",
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             color=STYLE_CONFIG["colors"]["success"])
    else:
        add_styled_paragraph(doc, "  ✅ 达标结果：改进目标达成，恢复正常绩效管理流程",
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             color=STYLE_CONFIG["colors"]["success"])
    if outcome_failure:
        add_styled_paragraph(doc, f"  ❌ 未达标结果：{outcome_failure}",
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             color=STYLE_CONFIG["colors"]["danger"])
    else:
        add_styled_paragraph(doc, "  ❌ 未达标结果：改进目标未达成，将启动进一步处理流程（包括但不限于调整岗位、解除劳动合同等）",
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             color=STYLE_CONFIG["colors"]["danger"])

    # 八、PIP到期处理流程
    doc.add_heading("八、PIP到期处理流程", level=1)
    pip_process = [
        "PIP到期前5个工作日，主管完成最终评估",
        "如达标：主管与HR确认，恢复正常绩效管理流程",
        "如部分达标：主管与HR讨论是否延长PIP（最多延长1个周期）",
        "如未达标：HR启动进一步处理流程，员工有权申诉",
        "所有评估结果书面记录，双方签字确认",
    ]
    for p_text in pip_process:
        add_styled_paragraph(doc, f"  {pip_process.index(p_text) + 1}. {p_text}",
                             font_size=STYLE_CONFIG["fonts"]["body"],
                             space_after=Pt(2))

    # 九、签字确认
    doc.add_heading("九、签字确认", level=1)
    add_styled_paragraph(doc, "本人已了解本改进计划的内容和要求，同意按照计划执行。本人理解如未能按期达成改进目标，将面临进一步的处理措施。",
                         font_size=STYLE_CONFIG["fonts"]["body"],
                         space_before=Pt(8))
    add_sign_table(doc, [
        ["员工签字", "", "日期", ""],
        ["主管签字", "", "日期", ""],
        ["HR签字", "", "日期", ""],
    ])

    doc.save(output_path)
    return output_path


# ==================== 导出路由 ====================

EXPORTERS = {
    "kpi_target": export_kpi_target,
    "okr_target": export_okr_target,
    "progress_report": export_progress_report,
    "evaluation_report": export_evaluation_report,
    "interview_guide": export_interview_guide,
    "pip_plan": export_pip_plan,
}


def export(material_type, data_or_file, output_path):
    """
    通用导出接口
    material_type: kpi_target/okr_target/progress_report/evaluation_report/interview_guide/pip_plan
    data_or_file: JSON数据字典 或 JSON文件路径
    output_path: 输出.docx文件路径
    """
    if material_type not in EXPORTERS:
        print(f"不支持的类型: {material_type}，可用类型: {', '.join(EXPORTERS.keys())}")
        sys.exit(1)

    if isinstance(data_or_file, str):
        with open(data_or_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    else:
        data = data_or_file

    exporter = EXPORTERS[material_type]
    result = exporter(data, output_path)
    print(f"导出成功: {result}")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="绩效管理Word文档导出工具")
    parser.add_argument("--type", "-t", required=True,
                        help="文档类型：kpi_target/okr_target/progress_report/evaluation_report/interview_guide/pip_plan")
    parser.add_argument("--input", "-i", required=True,
                        help="输入JSON数据文件路径")
    parser.add_argument("--output", "-o", required=True,
                        help="输出.docx文件路径")

    args = parser.parse_args()
    export(args.type, args.input, args.output)
