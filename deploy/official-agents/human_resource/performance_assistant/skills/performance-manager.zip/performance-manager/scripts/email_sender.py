#!/usr/bin/env python3
"""
培训材料邮件发送脚本
支持：培训通知、材料分发、考核通知等场景
支持附件发送（Word文档等）
"""

import sys
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from pathlib import Path
from datetime import datetime


# ==================== 邮件模板 ====================

EMAIL_TEMPLATES = {
    "performance_notification": """
{recipient_name}您好，

{company_name}绩效管理相关通知如下：

📋 通知类型：{notification_type}
👤 员工姓名：{employee_name}
📅 考核周期：{period}
📌 相关说明：{description}

详细内容请查看随邮件附上的绩效文档。

如有疑问，请联系HR部门。

此致
{company_name}人力资源部
    """,

    "evaluation_result": """
{recipient_name}您好，

{period}绩效评估结果已出，请查收：

📊 综合评级：{rating}
📝 评估周期：{period}
👤 评估对象：{employee_name}

详细评估报告已随邮件附上，请查阅。

📌 后续事项：
1. 请在收到评估结果后3个工作日内确认
2. 如有异议，请与直属主管沟通
3. 绩效面谈安排将另行通知

此致
{company_name}人力资源部
    """,

    "interview_appointment": """
{recipient_name}您好，

{period}绩效面谈安排如下：

📅 面谈时间：{interview_time}
📍 面谈地点：{interview_location}
👤 面谈人：{interviewer}
📝 面谈类型：{interview_type}

📌 准备事项：
1. 请提前回顾本周期的工作目标和完成情况
2. 准备好自我评价和改进建议
3. 如有需要讨论的问题，请提前整理

请准时参加，如有时间冲突请提前沟通。

此致
{company_name}人力资源部
    """,

    "pip_notification": """
{recipient_name}您好，

根据绩效评估结果，您需要进入绩效改进计划（PIP），详情如下：

📋 改进周期：{period}
🎯 改进目标：{improvement_goals}
📅 起始日期：{start_date}
📅 截止日期：{end_date}

📌 重要说明：
1. PIP期间将安排定期检查节点
2. 公司将提供必要的培训和支持资源
3. 请认真对待改进计划，积极改进

详细改进计划已随邮件附上。如有疑问，请联系您的直属主管或HR BP。

此致
{company_name}人力资源部
    """
}


def send_email(smtp_config, recipient, subject, body, is_html=False, attachments=None):
    """
    发送邮件
    smtp_config: SMTP配置字典
    recipient: 收件人邮箱
    subject: 邮件主题
    body: 邮件正文
    is_html: 是否HTML格式
    attachments: 附件文件路径列表
    """
    try:
        msg = MIMEMultipart()
        msg['From'] = f"{smtp_config.get('sender_name', '')} <{smtp_config['sender_email']}>"
        msg['To'] = recipient
        msg['Subject'] = subject

        # 邮件正文
        if is_html:
            msg.attach(MIMEText(body, 'html', 'utf-8'))
        else:
            msg.attach(MIMEText(body, 'plain', 'utf-8'))

        # 添加附件
        if attachments:
            for file_path in attachments:
                file_path = Path(file_path)
                if not file_path.exists():
                    print(f"警告: 附件不存在，已跳过: {file_path}")
                    continue

                with open(file_path, 'rb') as f:
                    part = MIMEBase('application', 'octet-stream')
                    part.set_payload(f.read())

                encoders.encode_base64(part)

                # 处理中文文件名
                filename = file_path.name
                try:
                    part.add_header(
                        'Content-Disposition',
                        'attachment',
                        filename=('utf-8', '', filename)
                    )
                except Exception:
                    part.add_header('Content-Disposition', 'attachment', filename=filename)

                msg.attach(part)

        # 连接 SMTP 服务器
        use_ssl = smtp_config.get('use_ssl', False)
        smtp_port = smtp_config.get('smtp_port', 465 if use_ssl else 587)

        if use_ssl:
            server = smtplib.SMTP_SSL(smtp_config['smtp_server'], smtp_port)
        else:
            server = smtplib.SMTP(smtp_config['smtp_server'], smtp_port)
            server.starttls()

        server.login(smtp_config['username'], smtp_config['password'])
        server.sendmail(smtp_config['sender_email'], recipient, msg.as_string())
        server.quit()

        return {"success": True, "message": f"邮件已发送至 {recipient}"}

    except Exception as e:
        return {"success": False, "error": str(e)}


def generate_email_content(template_name, data):
    """根据模板生成邮件内容"""
    if template_name not in EMAIL_TEMPLATES:
        return {"error": f"未找到模板: {template_name}，可用模板: {', '.join(EMAIL_TEMPLATES.keys())}"}

    template = EMAIL_TEMPLATES[template_name]
    content = template
    for key, value in data.items():
        placeholder = "{" + key + "}"
        content = content.replace(placeholder, str(value))

    return {"content": content.strip()}


def main():
    if len(sys.argv) < 2:
        print("培训材料邮件发送工具")
        print("用法：")
        print("  生成邮件: python email_sender.py generate <template_name> <data_json_file>")
        print("  发送邮件: python email_sender.py send <smtp_config_file> <recipient> <subject> <body_file> [attachment1] [attachment2] ...")
        print("\n可用模板：")
        for name, tmpl in EMAIL_TEMPLATES.items():
            print(f"  - {name}")
        sys.exit(1)

    action = sys.argv[1]

    if action == "generate":
        if len(sys.argv) < 4:
            print("用法: python email_sender.py generate <template_name> <data_json_file>")
            sys.exit(1)

        template_name = sys.argv[2]
        data_file = sys.argv[3]

        with open(data_file, 'r', encoding='utf-8') as f:
            data = json.load(f)

        result = generate_email_content(template_name, data)

        if 'error' in result:
            print(f"错误: {result['error']}")
            sys.exit(1)
        else:
            print(result['content'])

    elif action == "send":
        if len(sys.argv) < 6:
            print("用法: python email_sender.py send <smtp_config_file> <recipient> <subject> <body_file> [attachment1] [attachment2] ...")
            sys.exit(1)

        smtp_config_file = sys.argv[2]
        recipient = sys.argv[3]
        subject = sys.argv[4]
        body_file = sys.argv[5]
        attachments = sys.argv[6:] if len(sys.argv) > 6 else None

        with open(smtp_config_file, 'r', encoding='utf-8') as f:
            smtp_config = json.load(f)

        with open(body_file, 'r', encoding='utf-8') as f:
            body = f.read()

        result = send_email(smtp_config, recipient, subject, body, attachments=attachments)

        if result['success']:
            print(result['message'])
        else:
            print(f"发送失败: {result['error']}")
            sys.exit(1)

    else:
        print(f"未知操作: {action}")
        sys.exit(1)


if __name__ == "__main__":
    main()
