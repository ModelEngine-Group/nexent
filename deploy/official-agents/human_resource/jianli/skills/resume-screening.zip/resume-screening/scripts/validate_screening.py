#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


REQUIRED_COLUMNS = (
    "候选人ID",
    "简历文件",
    "结论",
    "必须条件匹配",
    "加分条件匹配",
    "不符合或缺失项",
    "依据位置",
    "理由",
    "人工复核建议",
)
ALLOWED_DECISIONS = {"符合条件", "不符合条件", "信息不足"}
SENSITIVE_TERMS = (
    "年龄",
    "性别",
    "婚姻",
    "婚育",
    "怀孕",
    "生育",
    "民族",
    "种族",
    "宗教",
    "残疾",
    "疾病",
    "健康",
    "籍贯",
    "外貌",
    "身高",
    "体重",
    "照片",
)
VAGUE_REASONS = ("感觉", "气质", "不稳定", "文化匹配", "眼缘", "看起来")


def split_row(line):
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


def is_separator(cells):
    return bool(cells) and all(re.fullmatch(r":?-{3,}:?", cell) for cell in cells)


def find_table(text):
    lines = text.splitlines()
    for index, line in enumerate(lines[:-1]):
        if not line.lstrip().startswith("|"):
            continue
        headers = split_row(line)
        if "候选人ID" not in headers or "结论" not in headers:
            continue
        separator = split_row(lines[index + 1])
        if len(separator) != len(headers) or not is_separator(separator):
            continue
        rows = []
        for row_line in lines[index + 2 :]:
            if not row_line.lstrip().startswith("|"):
                break
            cells = split_row(row_line)
            if len(cells) != len(headers):
                rows.append({"__invalid__": cells})
            else:
                rows.append(dict(zip(headers, cells)))
        return headers, rows
    return [], []


def validate(path):
    text = path.read_text(encoding="utf-8")
    headers, rows = find_table(text)
    errors = []
    warnings = []

    if not headers:
        return ["没有找到包含候选人ID和结论列的筛选总表"], warnings, 0

    missing = [column for column in REQUIRED_COLUMNS if column not in headers]
    if missing:
        errors.append(f"缺少必需列: {', '.join(missing)}")
    if not rows:
        errors.append("筛选总表没有候选人记录")

    ids = []
    for number, row in enumerate(rows, start=1):
        if "__invalid__" in row:
            errors.append(f"第 {number} 行列数与表头不一致")
            continue
        candidate_id = row.get("候选人ID", "").strip() or f"第{number}行"
        ids.append(candidate_id)
        for field in REQUIRED_COLUMNS:
            if not row.get(field, "").strip():
                errors.append(f"{candidate_id} 的 {field} 为空")

        decision = row.get("结论", "").strip()
        if decision and decision not in ALLOWED_DECISIONS:
            errors.append(f"{candidate_id} 的结论无效: {decision}")

        reason = row.get("理由", "")
        if any(term in reason for term in VAGUE_REASONS):
            errors.append(f"{candidate_id} 的理由包含主观或模糊判断")
        if any(term in " ".join(row.values()) for term in SENSITIVE_TERMS):
            errors.append(f"{candidate_id} 的筛选记录包含敏感属性")

        if decision == "不符合条件":
            gap = row.get("不符合或缺失项", "").strip()
            evidence = row.get("依据位置", "").strip()
            if gap in {"无", "-", "没有"}:
                errors.append(f"{candidate_id} 标为不符合但没有明确必须条件缺口")
            if evidence in {"无", "-", "没有", "未说明"}:
                errors.append(f"{candidate_id} 标为不符合但没有证据位置")

        if decision == "信息不足" and "未知" not in reason and "未" not in row.get("不符合或缺失项", ""):
            warnings.append(f"{candidate_id} 的信息不足没有清楚标明未知项")

    if len(ids) != len(set(ids)):
        errors.append("候选人ID重复")
    if "[事实]" not in text or "[未知]" not in text:
        warnings.append("报告没有同时展示 [事实] 和 [未知] 标记")

    return errors, sorted(set(warnings)), len(rows)


def main():
    parser = argparse.ArgumentParser(description="检查简历筛选报告的结构、证据和敏感条件。")
    parser.add_argument("report", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if not args.report.exists():
        result = {"passed": False, "candidate_count": 0, "errors": ["报告文件不存在"], "warnings": []}
    else:
        errors, warnings, count = validate(args.report)
        result = {"passed": not errors, "candidate_count": count, "errors": errors, "warnings": warnings}

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"passed={result['passed']} candidates={result['candidate_count']} errors={len(result['errors'])} warnings={len(result['warnings'])}")
        for item in result["errors"]:
            print(f"ERROR: {item}")
        for item in result["warnings"]:
            print(f"WARN: {item}")
    raise SystemExit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()
