# China Lawyer Analyst v3.1.0 - 项目结构

## 目录树

```
china-lawyer-analyst/
├── 📄 核心文件
│   ├── SKILL.md                      # Skill 主文档 (v3.1.0)
│   ├── metadata.json                 # 元数据索引 (v3.1.0)
│   ├── router.md                     # 路由系统 (v3.0.0 两级路由)
│   ├── USER_GUIDE.md                 # 用户使用指南 ⭐
│   ├── CHANGELOG.md                  # 更新日志
│   ├── COMPLETION_REPORT.md          # 完成报告
│   └── PROJECT_STRUCTURE.md          # 本文件
│
├── 📂 核心模块
│   └── core/                         # 核心理论（稳定）
│       ├── philosophy.md              # 核心哲学
│       ├── foundations-universal.md   # 通用理论支柱
│       ├── frameworks-core.md        # 核心分析框架
│       └── process.md                # 10步法流程
│
├── 📂 领域模块
│   └── domains/                      # 8大法律领域（稳定）
│       ├── contract-law.md           # 合同法
│       ├── tort-law.md               # 侵权法
│       ├── construction-law.md       # 建设工程
│       ├── corporate-law.md           # 公司法
│       ├── investment-law.md         # 投融资
│       ├── labor-law.md              # 劳动法
│       ├── ip-law.md                 # 知识产权
│       └── litigation-arbitration.md # 诉讼仲裁
│
├── 📂 司法解释索引系统（v3.0 新增）⭐
│   └── interpretations/
│       ├── README.md                 # 索引系统说明
│       ├── metadata.json             # 全局元数据索引
│       ├── _template/               # 模板目录
│       │   ├── README.md
│       │   ├── index.md
│       │   ├── metadata.json
│       │   ├── external-links.md
│       │   └── articles/.gitkeep
│       ├── contract-general-2023/    # 合同编通则解释（2023）
│       │   ├── README.md             # 模块概要
│       │   ├── index.md              # 条文索引
│       │   ├── metadata.json         # 模块元数据
│       │   └── articles/             # 条文详解（14个）
│       │       ├── article-6.md      # 预约合同认定
│       │       ├── article-7.md      # 违反预约合同
│       │       ├── article-8.md      # 违约责任
│       │       ├── article-12.md     # 批准生效合同
│       │       ├── article-16.md     # 违反强制性规定
│       │       ├── article-17.md     # 违背公序良俗
│       │       ├── article-19.md     # 无权处分
│       │       ├── article-20.md     # 越权代表
│       │       ├── article-27.md     # 债务履行期后以物抵债
│       │       ├── article-28.md     # 债务履行期前以物抵债
│       │       ├── article-60.md     # 可得利益损失
│       │       ├── article-65.md     # 违约金调整
│       │       ├── article-67.md     # 定金性质认定
│       │       └── article-68.md     # 定金罚则
│       └── security-law-2020/        # 担保制度解释（2020）
│           ├── README.md             # 模块概要
│           ├── index.md              # 条文索引
│           ├── metadata.json         # 模块元数据
│           └── articles/             # 条文详解（12个）
│               ├── article-2.md      # 担保合同从属性
│               ├── article-6.md      # 公司对外担保决议机关
│               ├── article-7.md      # 相对人善意标准
│               ├── article-8.md      # 无决议担保例外
│               ├── article-12.md     # 债务加入准用担保规则
│               ├── article-25.md     # 保证方式认定
│               ├── article-28.md     # 一般保证先诉抗辩权
│               ├── article-32.md     # 保证期间与诉讼时效
│               ├── article-37.md     # 抵押财产转让
│               ├── article-46.md     # 不动产抵押预告登记
│               ├── article-54.md     # 流动抵押
│               └── article-57.md     # 价款优先权PMSI
│
├── 📂 共享模块
│   └── shared/
│       ├── methods/                  # 法律方法论
│       ├── resources/                # 法律资源
│       └── verification/             # 验证工具
│
├── 📂 自动化工具（v3.1 新增）⭐⭐⭐
│   └── tools/
│       ├── README.md                 # 工具使用说明
│       ├── SUMMARY.md                # 开发完成总结
│       ├── requirements.txt          # Python 依赖
│       ├── quick-start.sh            # 快速启动脚本
│       ├── setup-cron.sh            # Cron 设置脚本
│       ├── check_update.py          # 快速更新检查
│       ├── cron-guide.md             # Cron 配置指南
│       │
│       ├── monitor/                  # 监测工具
│       │   ├── court-monitor.py      # 最高法院监测脚本
│       │   └── config.yml           # 监测配置
│       │
│       ├── retrieval/                # 检索工具
│       │   ├── enhanced_retrieval.py # 增强检索工具
│       │   └── test_retrieval.py    # 测试脚本
│       │
│       ├── examples/                 # 示例代码
│       │   └── integration_example.py # Skill 集成示例
│       │
│       ├── router_integration.py     # 三级路由集成
│       │
│       └── workflows/                # 工作流程
│           ├── review-checklist.md  # 审核清单
│           └── update-workflow.md    # 更新流程
│
└── 📂 其他
    ├── _template/                   # 旧模板（已废弃）
    └── domains-archives/             # 旧版本文档（已废弃）
```

---

## 文件统计

| 类别 | 数量 | 占比 |
|------|------|------|
| **核心文件** | 7 | 15% |
| **核心模块** | 4 | 9% |
| **领域模块** | 8 | 17% |
| **司法解释模块** | 30 | 64% |
| **工具脚本** | 11 | 23% |
| **文档** | 18 | 38% |
| **总计** | ~47 | 100% |

---

## 关键文件说明

### ⭐ 必读文件

1. **[USER_GUIDE.md](USER_GUIDE.md)** - 用户使用指南
2. **[tools/README.md](tools/README.md)** - 工具使用说明
3. **[SKILL.md](SKILL.md)** - Skill 主文档
4. **[CHANGELOG.md](CHANGELOG.md)** - 更新日志

### 🔧 核心工具

1. **tools/monitor/court-monitor.py** - 监测新司法解释
2. **tools/retrieval/enhanced_retrieval.py** - 增强检索
3. **tools/check_update.py** - 快速更新检查
4. **tools/quick-start.sh** - 快速启动

### 📚 司法解释模块

1. **interpretations/contract-general-2023/** - 合同编通则解释
2. **interpretations/security-law-2020/** - 担保制度解释

---

## 版本信息

- **当前版本**：v3.1.0
- **发布日期**：2026-01-16
- **下次审查**：根据司法解释更新频率

---

**维护者**：china-lawyer-analyst 项目组
