﻿# patent_reader.extract

