﻿# patent_reader.analyze

