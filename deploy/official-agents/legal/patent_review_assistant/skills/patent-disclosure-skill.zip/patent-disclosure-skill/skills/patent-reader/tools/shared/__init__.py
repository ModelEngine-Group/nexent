﻿# patent_reader.shared

