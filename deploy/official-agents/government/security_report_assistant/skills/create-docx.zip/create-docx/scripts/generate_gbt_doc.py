#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""严格按照 GB/T 9704-2012 党政机关公文格式生成通知"""

import argparse
import json
from pathlib import Path
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml

def set_font(run, font_cn, font_en, size_pt, bold=False, color=None):
    """设置中英文字体"""
    run.font.size = Pt(size_pt)
    run.font.bold = bold
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = parse_xml(f'<w:rFonts {nsdecls("w")} />')
        rPr.insert(0, rFonts)
    rFonts.set(qn('w:eastAsia'), font_cn)
    rFonts.set(qn('w:ascii'), font_en)
    rFonts.set(qn('w:hAnsi'), font_en)
    if color:
        run.font.color.rgb = color

def set_line_spacing(paragraph, line_spacing_pt):
    """设置固定行距(磅)"""
    pPr = paragraph._element.get_or_add_pPr()
    spacing = pPr.find(qn('w:spacing'))
    if spacing is None:
        spacing = parse_xml(f'<w:spacing {nsdecls("w")} />')
        pPr.append(spacing)
    spacing.set(qn('w:line'), str(int(line_spacing_pt * 20)))
    spacing.set(qn('w:lineRule'), 'exact')

def set_first_line_indent(paragraph, chars=2, font_size_pt=16):
    """首行缩进(字符数)"""
    pPr = paragraph._element.get_or_add_pPr()
    ind = pPr.find(qn('w:ind'))
    if ind is None:
        ind = parse_xml(f'<w:ind {nsdecls("w")} />')
        pPr.append(ind)
    indent_val = int(chars * font_size_pt * 20)
    ind.set(qn('w:firstLine'), str(indent_val))

def set_right_indent(paragraph, chars=4, font_size_pt=16):
    """右缩进(字符数)"""
    pPr = paragraph._element.get_or_add_pPr()
    ind = pPr.find(qn('w:ind'))
    if ind is None:
        ind = parse_xml(f'<w:ind {nsdecls("w")} />')
        pPr.append(ind)
    ind.set(qn('w:right'), str(int(chars * font_size_pt * 20)))

def add_separator_line(doc, color_hex="FF0000", thickness=12):
    """添加分隔线"""
    p = doc.add_paragraph()
    pPr = p._element.get_or_add_pPr()
    spacing = parse_xml(f'<w:spacing {nsdecls("w")} w:before="0" w:after="0" w:line="20" w:lineRule="exact"/>')
    pPr.append(spacing)
    pBdr = parse_xml(
        f'<w:pBdr {nsdecls("w")}>'
        f'<w:bottom w:val="single" w:sz="{thickness}" w:space="1" w:color="{color_hex}"/>'
        f'</w:pBdr>'
    )
    pPr.append(pBdr)
    p.add_run('')

def add_empty_line(doc, line_spacing_pt=28):
    """添加空行"""
    p = doc.add_paragraph()
    set_line_spacing(p, line_spacing_pt)

def add_para(doc, text, font_cn, font_en, size_pt, bold=False, alignment=None,
             first_indent=0, line_spacing=28, right_indent=0, color=None):
    """添加格式化段落"""
    p = doc.add_paragraph()
    run = p.add_run(text)
    set_font(run, font_cn, font_en, size_pt, bold, color)
    set_line_spacing(p, line_spacing)
    if alignment is not None:
        p.alignment = alignment
    if first_indent > 0:
        set_first_line_indent(p, first_indent, size_pt)
    if right_indent > 0:
        set_right_indent(p, right_indent, size_pt)
    return p

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', '-o', required=True, help='Output file path')
    args = parser.parse_args()

    doc = Document()

    # ===== 页面设置: A4, 上37mm 下35mm 左28mm 右26mm =====
    for sec in doc.sections:
        sec.page_width = Cm(21.0)
        sec.page_height = Cm(29.7)
        sec.top_margin = Cm(3.7)
        sec.bottom_margin = Cm(3.5)
        sec.left_margin = Cm(2.8)
        sec.right_margin = Cm(2.6)

    # ===== 版头: 发文字号(三号仿宋居中) + 红色分隔线 =====
    add_para(doc, '安监发〔2024〕12号', '仿宋', '仿宋', 16,
             alignment=WD_PARAGRAPH_ALIGNMENT.CENTER, line_spacing=28)
    add_separator_line(doc, "FF0000", 12)
    add_empty_line(doc, 28)

    # ===== 标题: 二号小标宋体居中 =====
    add_para(doc, '关于召开2024年度安全生产工作会议的通知',
             '小标宋体', 'Times New Roman', 22,
             alignment=WD_PARAGRAPH_ALIGNMENT.CENTER, line_spacing=36)
    add_empty_line(doc, 28)

    # ===== 主送机关: 三号仿宋顶格 =====
    add_para(doc, '各部门：', '仿宋', '仿宋', 16, line_spacing=28)

    # ===== 正文引言: 三号仿宋，首行缩进2字符 =====
    add_para(doc, '为全面总结2024年度安全生产工作，深入分析当前安全生产形势，部署下一阶段重点任务，经研究决定，召开2024年度安全生产工作会议。现将有关事项通知如下：',
             '仿宋', '仿宋', 16, alignment=WD_PARAGRAPH_ALIGNMENT.JUSTIFY,
             first_indent=2, line_spacing=28)

    # ===== 一、会议时间 (三号黑体) =====
    add_para(doc, '一、会议时间', '黑体', '黑体', 16, line_spacing=28)
    add_para(doc, '2024年12月20日（星期五）上午9:00，会期半天。',
             '仿宋', '仿宋', 16, alignment=WD_PARAGRAPH_ALIGNMENT.JUSTIFY,
             first_indent=2, line_spacing=28)

    # ===== 二、会议地点 =====
    add_para(doc, '二、会议地点', '黑体', '黑体', 16, line_spacing=28)
    add_para(doc, '公司三楼第一会议室。',
             '仿宋', '仿宋', 16, alignment=WD_PARAGRAPH_ALIGNMENT.JUSTIFY,
             first_indent=2, line_spacing=28)

    # ===== 三、参会人员 =====
    add_para(doc, '三、参会人员', '黑体', '黑体', 16, line_spacing=28)
    # 二级标题: 三号楷体
    for item in ['（一）公司领导班子成员；', '（二）各部门负责人；', '（三）各部门专（兼）职安全员。']:
        add_para(doc, item, '楷体', '楷体', 16, first_indent=2, line_spacing=28)

    # ===== 四、会议内容 =====
    add_para(doc, '四、会议内容', '黑体', '黑体', 16, line_spacing=28)
    for item in ['（一）总结2024年度安全生产工作成效与不足；',
                 '（二）通报2024年度安全生产考核情况；',
                 '（三）部署2025年度安全生产重点工作任务；',
                 '（四）签订2025年度安全生产目标责任书。']:
        add_para(doc, item, '楷体', '楷体', 16, first_indent=2, line_spacing=28)

    # ===== 五、有关要求 =====
    add_para(doc, '五、有关要求', '黑体', '黑体', 16, line_spacing=28)
    for item in ['（一）请各部门于12月15日前将年度安全工作总结及参会人员名单报送安全管理部；',
                 '（二）请参会人员提前10分钟入场，严格遵守会场纪律；',
                 '（三）确有特殊情况不能参会的，须提前向安全管理部书面请假；',
                 '（四）会议期间请关闭手机或调至静音模式。']:
        add_para(doc, item, '楷体', '楷体', 16, first_indent=2, line_spacing=28)

    # ===== 发文机关署名和成文日期: 正文下空二行，右空四字 =====
    add_empty_line(doc, 28)
    add_empty_line(doc, 28)
    add_para(doc, '公司安全管理部', '仿宋', '仿宋', 16,
             alignment=WD_PARAGRAPH_ALIGNMENT.RIGHT, right_indent=4, line_spacing=28)
    add_para(doc, '2024年12月6日', '仿宋', '仿宋', 16,
             alignment=WD_PARAGRAPH_ALIGNMENT.RIGHT, right_indent=4, line_spacing=28)

    # ===== 版记: 抄送 + 印发信息 =====
    for _ in range(6):
        add_empty_line(doc, 28)
    add_separator_line(doc, "000000", 4)
    add_para(doc, '抄送：公司领导，各分公司。', '仿宋', '仿宋', 14, line_spacing=26)
    add_separator_line(doc, "000000", 4)
    add_para(doc, '公司安全管理部                    2024年12月6日印发',
             '仿宋', '仿宋', 14, line_spacing=26)

    # 保存
    output_path = args.output
    doc.save(output_path)
    print(json.dumps({
        "status": "success",
        "file_path": output_path,
        "paragraphs": len(doc.paragraphs)
    }, ensure_ascii=False))

if __name__ == '__main__':
    main()
