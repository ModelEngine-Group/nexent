#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""在内存中统计网络安全事件；不读写文件。"""

import argparse
import base64
import json
import sys
from collections import Counter

LEVEL_KEYS = ["威胁等级", "事件等级", "等级", "severity", "level", "threat_level"]
RESULT_KEYS = ["攻击结果", "事件结果", "结果", "result", "attack_result"]
TYPE_KEYS = ["事件类型", "攻击类型", "类型", "event_type", "type", "category"]
ATTACKER_KEYS = ["攻击者", "攻击者IP", "源IP", "源地址", "attacker", "src_ip", "source_ip"]
VICTIM_KEYS = ["被攻击者", "目标IP", "目的IP", "目标地址", "victim", "dst_ip", "dest_ip", "destination_ip"]


def normalize_key(value):
    return "".join(str(value).split()).lower().replace("_", "").replace("-", "")


def find_value(row, keys):
    wanted = {normalize_key(key) for key in keys}
    for field, value in row.items():
        if normalize_key(field) in wanted and value not in (None, ""):
            return str(value).strip() or "未知"
    return "未知"


def parse_records(raw):
    data = json.loads(raw)
    if isinstance(data, list):
        records = data
    elif isinstance(data, dict):
        records = next((data[key] for key in ("data", "events", "records", "list") if isinstance(data.get(key), list)), None)
        if records is None and all(not isinstance(value, (list, dict)) for value in data.values()):
            records = [data]
    else:
        records = None
    if not records or not all(isinstance(item, dict) for item in records):
        raise ValueError("输入必须是非空 JSON 对象数组，或包含 data/events/records/list 数组的对象。")
    return records


def build_distribution(counter):
    total = sum(counter.values())
    return {
        "total": total,
        "items": [
            {"name": name, "count": count, "percentage": round(count * 100.0 / total, 2)}
            for name, count in sorted(counter.items(), key=lambda item: (-item[1], item[0]))
        ],
    }


def analyze(records):
    counters = [Counter() for _ in range(5)]
    fields = (LEVEL_KEYS, RESULT_KEYS, TYPE_KEYS, ATTACKER_KEYS, VICTIM_KEYS)
    for row in records:
        for counter, keys in zip(counters, fields):
            counter[find_value(row, keys)] += 1
    level, result, event_type, attacker, victim = counters
    return {
        "total_events": len(records),
        "threat_level_distribution": build_distribution(level),
        "attack_result_distribution": build_distribution(result),
        "event_type_distribution": build_distribution(event_type),
        "top_attackers": build_distribution(attacker),
        "top_victims": build_distribution(victim),
    }


def main():
    parser = argparse.ArgumentParser(description="在内存中统计网络安全事件，不读写文件。")
    parser.add_argument("--data", help="JSON 字符串；省略时从标准输入读取。")
    parser.add_argument("--data-base64", help="UTF-8 JSON 的 Base64 字符串，适合避免 PowerShell 引号问题。")
    parser.add_argument("--expected-count", type=int, help="期望的记录数；不一致时返回失败。")
    args = parser.parse_args()
    if args.data is not None and args.data_base64 is not None:
        raise ValueError("--data 与 --data-base64 只能二选一。")
    if args.data_base64 is not None:
        try:
            raw = base64.b64decode(args.data_base64, validate=True).decode("utf-8")
        except (ValueError, UnicodeDecodeError) as exc:
            raise ValueError(f"Base64 JSON 解码失败: {exc}") from exc
    else:
        raw = args.data if args.data is not None else sys.stdin.read()
    if not raw.strip():
        raise ValueError("未收到 JSON 输入。")
    records = parse_records(raw)
    if args.expected_count is not None and len(records) != args.expected_count:
        raise ValueError(f"记录数校验失败：收到 {len(records)} 条，期望 {args.expected_count} 条。")
    stats = analyze(records)
    print(json.dumps({"ok": True, "input_records": len(records), "stats": stats}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stdout)
        raise SystemExit(2)
