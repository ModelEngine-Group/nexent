#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""无第三方和无标准库导入的事件统计脚本。

输入为制表符分隔文本：首行可选 # expected_count=20，随后是固定表头
severity<TAB>result<TAB>event_type<TAB>attacker<TAB>victim，之后每行一条记录。
"""


FIELDS = ("severity", "result", "event_type", "attacker", "victim")


def count_values(rows, index):
    counts = {}
    for row in rows:
        value = row[index].strip() or "未知"
        counts[value] = counts.get(value, 0) + 1
    return counts


def print_distribution(title, counts, total):
    print("SECTION\t" + title)
    names = list(counts.keys())
    names.sort(key=lambda name: (-counts[name], name))
    for name in names:
        percentage = round(counts[name] * 100.0 / total, 2)
        print("ITEM\t" + name + "\t" + str(counts[name]) + "\t" + str(percentage))


def main():
    lines = input_lines()
    expected = ""
    if lines and lines[0].startswith("# expected_count="):
        expected = lines.pop(0).split("=", 1)[1].strip()
    if not lines or lines.pop(0).split("\t") != list(FIELDS):
        fail("首行必须是固定表头：severity\\tresult\\tevent_type\\tattacker\\tvictim")
    rows = []
    for line_number, line in enumerate(lines, 2):
        row = line.split("\t")
        if len(row) != 5:
            fail("第 " + str(line_number) + " 行不是 5 列制表符文本")
        rows.append(row)
    if not rows:
        fail("未收到事件记录")
    if expected and len(rows) != int(expected):
        fail("记录数不符：收到 " + str(len(rows)) + " 条，期望 " + expected + " 条")
    total = len(rows)
    print("OK\ttrue")
    print("TOTAL_EVENTS\t" + str(total))
    print_distribution("THREAT_LEVEL", count_values(rows, 0), total)
    print_distribution("ATTACK_RESULT", count_values(rows, 1), total)
    print_distribution("EVENT_TYPE", count_values(rows, 2), total)
    print_distribution("TOP_ATTACKERS", count_values(rows, 3), total)
    print_distribution("TOP_VICTIMS", count_values(rows, 4), total)


def input_lines():
    lines = []
    while True:
        try:
            lines.append(input())
        except EOFError:
            return lines


def fail(message):
    print("OK\tfalse")
    print("ERROR\t" + message)
    raise SystemExit(2)


if __name__ == "__main__":
    main()
