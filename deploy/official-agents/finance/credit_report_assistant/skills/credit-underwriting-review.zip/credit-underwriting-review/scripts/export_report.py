#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
信贷授信审查报告 — 双格式导出器（fallback）
当运行环境无 libreoffice/soffice 时，用本脚本直接由 Markdown 主稿生成
Word(.docx) 与 PDF 双格式，符合 credit-underwriting-review 技能 Step8 的"双格式强制交付"要求。

依赖（隔离 venv 安装）：python-docx, reportlab
用法：python export_report.py <report.md>
输出：与输入同目录、同名的 .docx 与 .pdf

© 所有者：金实宏成。允许为使用目的安装、使用及提供给他人；禁止修改、反编译、去除所有权标识或分发修改版本。
"""

import os
import re
import sys

# ---------- 中文字体 ----------
FONT_CANDIDATES = [
    "/Library/Fonts/Arial Unicode.ttf",
    "/System/Library/Fonts/STHeiti Light.ttc",
    "/usr/share/fonts/truetype/arphic/uming.ttc",
]


def register_cjk_font():
    """注册一个可用的中文字体，返回字体名；失败则返回 Helvetica。"""
    try:
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
    except Exception:
        return "Helvetica"
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            try:
                idx = 0 if p.lower().endswith(".ttc") else 0
                pdfmetrics.registerFont(TTFont("CJK", p, subfontIndex=idx))
                return "CJK"
            except Exception:
                continue
    return "Helvetica"


# ---------- Markdown 解析 ----------
EMOJI_RE = re.compile("[\U0001F534\U0001F7E0\U0001F7E1\U0001F7E2\U0001F535]")


def strip_emoji(text: str) -> str:
    """PDF 用 Arial Unicode 不含彩色 emoji，去除后保留汉字等级（极高/较高等）。"""
    return EMOJI_RE.sub("", text).strip()


def is_sep_row(cells):
    return all(re.fullmatch(r"[-: ]+", c) for c in cells)


def parse_md(path):
    with open(path, encoding="utf-8") as f:
        lines = f.read().splitlines()
    blocks = []
    i, n = 0, len(lines)
    while i < n:
        line = lines[i]
        if line.strip() == "":
            i += 1
            continue
        if line.strip().startswith("```"):
            i += 1
            continue
        if line.startswith("### "):
            blocks.append(("h3", line[4:].strip())); i += 1; continue
        if line.startswith("## "):
            blocks.append(("h2", line[3:].strip())); i += 1; continue
        if line.startswith("# "):
            blocks.append(("h1", line[2:].strip())); i += 1; continue
        if line.startswith("> "):
            txt = []
            while i < n and lines[i].startswith("> "):
                txt.append(lines[i][2:].strip()); i += 1
            blocks.append(("quote", " ".join(txt))); continue
        if line.startswith("|"):
            rows = []
            while i < n and lines[i].startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")]); i += 1
            if len(rows) >= 1:
                header = rows[0]
                data = [r for r in rows[1:] if not is_sep_row(r)]
                blocks.append(("table", (header, data)))
            continue
        if re.match(r"^\s*[-*] ", line):
            items = []
            while i < n and re.match(r"^\s*[-*] ", lines[i]):
                items.append(re.sub(r"^\s*[-*] ", "", lines[i]).strip()); i += 1
            blocks.append(("ul", items)); continue
        para = []
        while (i < n and lines[i].strip() != ""
               and not lines[i].startswith("#") and not lines[i].startswith(">")
               and not lines[i].startswith("|") and not re.match(r"^\s*[-*] ", lines[i])):
            para.append(lines[i].strip()); i += 1
        blocks.append(("p", " ".join(para)))
    return blocks


# ---------- 生成 docx ----------
def build_docx(blocks, out_path):
    from docx import Document
    doc = Document()
    for kind, data in blocks:
        if kind == "h1":
            doc.add_heading(data, level=0)
        elif kind == "h2":
            doc.add_heading(data, level=1)
        elif kind == "h3":
            doc.add_heading(data, level=2)
        elif kind == "p":
            doc.add_paragraph(data)
        elif kind == "quote":
            p = doc.add_paragraph(data); p.italic = True
        elif kind == "ul":
            for it in data:
                doc.add_paragraph(it, style="List Bullet")
        elif kind == "table":
            header, tdata = data
            t = doc.add_table(rows=1, cols=max(len(header), 1))
            t.style = "Table Grid"
            for j, c in enumerate(header):
                t.rows[0].cells[j].text = c
            for row in tdata:
                cells = t.add_row().cells
                for j, c in enumerate(row):
                    if j < len(cells):
                        cells[j].text = c
    doc.save(out_path)


# ---------- 生成 pdf ----------
def build_pdf(blocks, out_path, font_name):
    from xml.sax.saxutils import escape
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                    TableStyle)

    body = ParagraphStyle("body", fontName=font_name, fontSize=9, leading=13)
    h1 = ParagraphStyle("h1", fontName=font_name, fontSize=16, leading=20,
                        spaceBefore=8, spaceAfter=8)
    h2 = ParagraphStyle("h2", fontName=font_name, fontSize=13, leading=17,
                        spaceBefore=10, spaceAfter=5)
    h3 = ParagraphStyle("h3", fontName=font_name, fontSize=11, leading=15,
                        spaceBefore=6, spaceAfter=3)
    quote = ParagraphStyle("quote", fontName=font_name, fontSize=9, leading=13,
                           leftIndent=10, textColor=colors.grey)
    cell = ParagraphStyle("cell", fontName=font_name, fontSize=8, leading=11)

    doc = SimpleDocTemplate(out_path, pagesize=A4,
                            leftMargin=1.8 * cm, rightMargin=1.8 * cm,
                            topMargin=1.6 * cm, bottomMargin=1.6 * cm)
    flow = []
    for kind, data in blocks:
        if kind == "h1":
            flow.append(Paragraph(escape(strip_emoji(data)), h1))
        elif kind == "h2":
            flow.append(Paragraph(escape(strip_emoji(data)), h2))
        elif kind == "h3":
            flow.append(Paragraph(escape(strip_emoji(data)), h3))
        elif kind == "p":
            flow.append(Paragraph(escape(strip_emoji(data)), body))
        elif kind == "quote":
            flow.append(Paragraph(escape(strip_emoji(data)), quote))
        elif kind == "ul":
            for it in data:
                flow.append(Paragraph("• " + escape(strip_emoji(it)), body))
        elif kind == "table":
            header, tdata = data
            table_data = [[Paragraph(escape(strip_emoji(c)), cell) for c in header]]
            for row in tdata:
                table_data.append([Paragraph(escape(strip_emoji(c)), cell) for c in row])
            t = Table(table_data, repeatRows=1, hAlign="LEFT")
            t.setStyle(TableStyle([
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("BACKGROUND", (0, 0), (-1, 0), colors.Color(0.85, 0.85, 0.85)),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]))
            flow.append(t)
            flow.append(Spacer(1, 6))
    doc.build(flow)


def main():
    if len(sys.argv) < 2:
        print("用法: python export_report.py <report.md>")
        sys.exit(1)
    md_path = sys.argv[1]
    if not os.path.exists(md_path):
        print(f"文件不存在: {md_path}")
        sys.exit(1)
    base = os.path.splitext(md_path)[0]
    out_docx = base + ".docx"
    out_pdf = base + ".pdf"

    blocks = parse_md(md_path)

    try:
        build_docx(blocks, out_docx)
        print(f"[OK] Word 已生成: {out_docx}")
    except Exception as e:
        print(f"[WARN] Word 生成失败: {e}（已保留 Markdown 主稿）")

    font_name = register_cjk_font()
    try:
        build_pdf(blocks, out_pdf, font_name)
        print(f"[OK] PDF  已生成: {out_pdf} (字体: {font_name})")
    except Exception as e:
        print(f"[WARN] PDF 生成失败: {e}（已保留 Markdown 主稿）")

    print("[DONE] 双格式导出完成。")


if __name__ == "__main__":
    main()
