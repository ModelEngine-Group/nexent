#!/usr/bin/env python3
"""
FAQ 导出器 — 将 qa_records.json 导出为答疑台账 .md 与 FAQ 交付物

用法:
    python faq_export.py qa_records.json --outdir ./output
    python faq_export.py qa_records.json --outdir ./output --mode faq

产出:
    默认模式（instant/batch 配套）:
        答疑台账.md          一题一行的答疑记录表（含待办跟进项汇总）
    faq 模式（题库沉淀配套）:
        FAQ题库.md           按分型×频次排序的完整题库
        话术速查卡.txt       高频条目一问一话术对照（助教速查用）

均不生成任何表格文件；.md 可继续交给 tencent-docx 排版为 .docx。

qa_records.json 格式见 references/qa-schema.md。

退出码: 0=成功  1=qa_records.json 无法读取或无记录  2=输出目录创建失败
"""

import sys
import os
import json
import argparse
from datetime import date

TYPE_ORDER = ["题目求解型", "知识概念型", "作业解析型", "方法策略型",
              "情绪态度型", "升学政策型", "事务服务型"]

TODAY = date.today().isoformat()


def load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def esc(s):
    """Markdown 表格/正文转义竖线与换行"""
    return str(s).replace("|", "\\|").replace("\n", " ")


def first_line(s, n=60):
    s = str(s).strip().split("\n")[0]
    return (s[:n] + "…") if len(s) > n else s


# ── 答疑台账 ─────────────────────────────────────────────
def export_ledger(data, outdir):
    meta = data.get("meta", {})
    records = data.get("records", [])
    anonymize = meta.get("anonymize", False)

    lines = []
    lines.append(f"# {meta.get('subject', '')}{meta.get('grade', '')}答疑台账")
    lines.append("")
    lines.append(f"> 课程：{meta.get('course_name', '—')} ｜ 学段：{meta.get('stage', '—')} ｜ "
                 f"模式：{meta.get('mode', '—')} ｜ 日期：{meta.get('date', TODAY)} ｜ "
                 f"记录数：{len(records)}")
    if meta.get("org_context"):
        lines.append(f">")
        lines.append(f"> 机构口径：{meta['org_context']}")
    lines.append("")

    lines.append("## 一、答疑记录总表")
    lines.append("")
    lines.append("| 问题号 | 学员 | 提问人 | 问题摘要 | 分型 | 难度档 | 置信度 | 状态 | 同题 |")
    lines.append("|--------|------|--------|----------|------|--------|--------|------|------|")
    letters = iter("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    name_map = {}
    for rec in records:
        name = rec.get("student", "—")
        if anonymize and name not in name_map:
            name_map[name] = f"学员{next(letters, '?')}"
        disp = name_map.get(name, name) if anonymize else name
        diag = rec.get("diagnosis", {})
        lines.append(
            f"| {rec.get('id', '—')} | {esc(disp)} | {rec.get('asker', '学员本人')} | "
            f"{esc(first_line(rec.get('question', ''), 24))} | {diag.get('question_type', '—')} | "
            f"{diag.get('difficulty_tier', '—')} | {rec.get('confidence', '—')} | "
            f"{rec.get('status', '待发送')} | {rec.get('same_as') or '—'} |")
    lines.append("")

    # 分型统计
    tc = {}
    for rec in records:
        t = rec.get("diagnosis", {}).get("question_type", "—")
        tc[t] = tc.get(t, 0) + 1
    lines.append("## 二、分型统计")
    lines.append("")
    for t in TYPE_ORDER + [k for k in tc if k not in TYPE_ORDER]:
        if t in tc:
            bar = "█" * tc[t]
            lines.append(f"- {t}：{bar} {tc[t]}")
    lines.append("")

    # 待办跟进项
    todos = [r for r in records
             if r.get("follow_up") or r.get("status") == "待教师确认"
             or r.get("diagnosis", {}).get("crisis")]
    lines.append("## 三、待办跟进项")
    lines.append("")
    if not todos:
        lines.append("（无待办事项）")
    else:
        lines.append("| 问题号 | 事项 | 紧急程度 |")
        lines.append("|--------|------|----------|")
        for rec in todos:
            diag = rec.get("diagnosis", {})
            urgent = "🔴 当日" if diag.get("crisis") else (
                "🟠 优先" if rec.get("confidence") == "低" else "🟢 常规")
            item = rec.get("follow_up") or ("需教师确认后发送" if rec.get("status") == "待教师确认" else "")
            lines.append(f"| {rec.get('id', '—')} | {esc(item)} | {urgent} |")
    lines.append("")

    # FAQ 候选
    faqs = [r for r in records if r.get("faq_worthy")]
    lines.append("## 四、FAQ 沉淀候选")
    lines.append("")
    if not faqs:
        lines.append("（本轮无 FAQ 候选）")
    else:
        for rec in sorted(faqs, key=lambda r: -r.get("faq_frequency", 1)):
            diag = rec.get("diagnosis", {})
            lines.append(f"- **{rec.get('id', '—')}**（频次 {rec.get('faq_frequency', 1)}）："
                         f"{esc(first_line(rec.get('question', ''), 40))} ｜ {diag.get('question_type', '—')}")
    lines.append("")

    out = os.path.join(outdir, "答疑台账.md")
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return out


# ── FAQ 题库与话术速查卡 ───────────────────────────────────
def build_faqs(records):
    """从记录聚合 FAQ 条目：same_as 合并 + faq_worthy 筛选"""
    groups = {}
    for rec in records:
        key = rec.get("same_as") or rec.get("id")
        groups.setdefault(key, []).append(rec)

    faqs = []
    for key, group in groups.items():
        main = next((r for r in group if r.get("id") == key), group[0])
        if not (main.get("faq_worthy") or any(r.get("faq_worthy") for r in group)):
            continue
        freq = sum(r.get("faq_frequency", 1) for r in group)
        diag = main.get("diagnosis", {})
        variants = []
        for r in group:
            q = str(r.get("question", "")).strip()
            if q and q != str(main.get("question", "")).strip() and q not in variants:
                variants.append(q)
        faqs.append({
            "question": str(main.get("question", "")).strip(),
            "variants": variants[:3],
            "question_type": diag.get("question_type", "—"),
            "knowledge_points": diag.get("knowledge_points", []),
            "answer": main.get("reply_sendable", "（待补：采用教师确认版口径）"),
            "talk_track": main.get("talk_track", ""),
            "frequency": freq,
            "source_ids": [r.get("id") for r in group],
        })

    # 组间排序：分型顺序 → 频次降序
    faqs.sort(key=lambda f: (TYPE_ORDER.index(f["question_type"])
                             if f["question_type"] in TYPE_ORDER else 99, -f["frequency"]))
    for i, f in enumerate(faqs, start=1):
        f["id"] = f"F{i:03d}"
    return faqs


def export_faq(data, outdir):
    meta = data.get("meta", {})
    faqs = build_faqs(data.get("records", []))

    # FAQ题库.md
    lines = []
    lines.append(f"# {meta.get('subject', '')}{meta.get('grade', '')}FAQ 题库")
    lines.append("")
    lines.append(f"> 课程：{meta.get('course_name', '—')} ｜ 生成日期：{TODAY} ｜ "
                 f"条目数：{len(faqs)} ｜ 来源记录：{meta.get('date', '')}")
    lines.append("")
    if not faqs:
        lines.append("（没有 faq_worthy 的记录，未生成 FAQ 条目。可在 qa_records.json 中标记后重跑。）")
    cur_type = None
    for f in faqs:
        if f["question_type"] != cur_type:
            cur_type = f["question_type"]
            lines.append(f"## {cur_type}")
            lines.append("")
        lines.append(f"### {f['id']}｜{f['question']}（频次 {f['frequency']}）")
        lines.append("")
        if f["variants"]:
            lines.append("**常见问法：** " + "；".join(f"「{v}」" for v in f["variants"]))
            lines.append("")
        if f["knowledge_points"]:
            lines.append(f"**关联知识点：** {'、'.join(f['knowledge_points'])}")
            lines.append("")
        lines.append("**标准答案：**")
        lines.append("")
        for ln in str(f["answer"]).split("\n"):
            lines.append(ln)
        lines.append("")
        if f.get("talk_track"):
            lines.append("**话术模板：**")
            lines.append("")
            for ln in str(f["talk_track"]).split("\n"):
                lines.append(ln)
            lines.append("")
        lines.append(f"**来源：** {', '.join(f['source_ids'])}")
        lines.append("---")
        lines.append("")

    out_md = os.path.join(outdir, "FAQ题库.md")
    with open(out_md, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    # 话术速查卡.txt
    card = []
    card.append(f"【{meta.get('subject', '')}·{meta.get('grade', '')} 答疑话术速查卡】"
                f"共{len(faqs)}条 · 更新于{TODAY}")
    card.append("─" * 24)
    for f in faqs:
        card.append(f"[{f['id']}] {f['question']}（频次{f['frequency']}）")
        card.append(f"答：{first_line(f['answer'], 60)}")
        if f.get("talk_track"):
            card.append(f"模板：{first_line(f['talk_track'], 60)}")
        card.append("─" * 24)
    out_txt = os.path.join(outdir, "话术速查卡.txt")
    with open(out_txt, "w", encoding="utf-8") as f:
        f.write("\n".join(card))

    return out_md, out_txt


def main():
    ap = argparse.ArgumentParser(description="导出答疑台账与 FAQ 交付物")
    ap.add_argument("path", help="qa_records.json 路径")
    ap.add_argument("--outdir", default="./output", help="输出目录（默认 ./output）")
    ap.add_argument("--mode", choices=["ledger", "faq"], default="ledger",
                    help="ledger=仅答疑台账（默认）；faq=FAQ 题库+话术速查卡")
    args = ap.parse_args()

    try:
        data = load(args.path)
    except FileNotFoundError:
        print(f"[ERROR] 文件不存在: {args.path}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"[ERROR] JSON 解析失败: {e}")
        sys.exit(1)

    if not data.get("records"):
        print("[ERROR] qa_records.json 中没有任何记录")
        sys.exit(1)

    try:
        os.makedirs(args.outdir, exist_ok=True)
    except OSError as e:
        print(f"[ERROR] 输出目录创建失败: {e}")
        sys.exit(2)

    if args.mode == "faq":
        out_md, out_txt = export_faq(data, args.outdir)
        n = len(build_faqs(data.get("records", [])))
        print(f"✓ FAQ题库: {out_md}（{n} 条）")
        print(f"✓ 话术速查卡: {out_txt}")
    else:
        out = export_ledger(data, args.outdir)
        print(f"✓ 答疑台账: {out}（{len(data['records'])} 条记录）")
    print("提示: .md 文件可交给 tencent-docx 排版为 .docx 后交付。")
    sys.exit(0)


if __name__ == "__main__":
    main()
