#!/usr/bin/env python3
"""
答疑校验器 — 校验答疑记录 qa_records.json 的完整性与规范性

用法:
    python qa_validator.py qa_records.json
    python qa_validator.py qa_records.json --json       # JSON 输出（供程序消费）
    python qa_validator.py qa_records.json --quiet      # 只输出结果，不输出统计

校验项:
    1. qa_records.json 结构：meta 必填字段（课程名/学段/年级/学科/模式）
    2. 问题编号：Q{XXX} 格式、全局连续、不重不跳
    3. 记录必备字段：id/student/question/diagnosis/reply_sendable/reply_confirm/confidence
    4. 枚举合法性：七分型、难度档、置信度、状态、模式、提问人
    5. 双版本完备：reply_sendable 与 reply_confirm 均非空；same_as 记录例外
    6. 教师确认纪律：题目求解型/升学政策型 必须 need_teacher_confirm=true
    7. 危机纪律：crisis=true 时 status 必须为"待教师确认"且 follow_up 非空
    8. 分布统计：分型分布、难度档分布、置信度分布、同题合并率、FAQ 候选数

qa_records.json 格式见 references/qa-schema.md。

退出码: 0=通过(含warning)  1=存在error  2=文件无法读取
"""

import sys
import json
import argparse

# ── 枚举定义（与 references/qa-schema.md 保持一致）────────────────────
VALID_TYPES = ["知识概念型", "题目求解型", "作业解析型", "方法策略型",
               "升学政策型", "情绪态度型", "事务服务型"]
VALID_TIERS = ["基础档", "标准档", "进阶档"]
VALID_DIFFS = ["易", "中", "难"]
VALID_CONF = ["高", "中", "低"]
VALID_STATUS = ["待发送", "已发送", "待教师确认", "已关闭"]
VALID_MODES = ["instant", "batch", "faq"]
VALID_STAGES = ["小学", "初中", "高中"]
VALID_ASKERS = ["学员", "家长", "助教转述"]

# 必须教师确认的分型
CONFIRM_REQUIRED_TYPES = {"题目求解型", "升学政策型"}

META_REQUIRED = ["course_name", "stage", "grade", "subject", "mode"]

RECORD_REQUIRED = ["id", "student", "question", "diagnosis",
                   "reply_sendable", "reply_confirm", "confidence"]

DIAG_REQUIRED = ["question_type", "knowledge_points", "difficulty_tier",
                 "strategy", "need_teacher_confirm"]

SENDABLE_MAX_LEN = 500          # 可发送版微信篇幅红线（字）
QUESTION_MAX_LEN = 200          # 问题原文上限（宽松，照片解析除外）


def check_id_format(rid, idx):
    """Q{XXX} 格式且与序位一致（1-based）"""
    ok_fmt = rid.startswith("Q") and rid[1:].isdigit() and len(rid) == 4
    return ok_fmt and int(rid[1:]) == idx


def validate(path):
    errors, warnings = [], []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return None, [f"文件不存在: {path}"], []
    except json.JSONDecodeError as e:
        return None, [f"JSON 解析失败: {e}"], []

    # ── meta 校验 ──
    meta = data.get("meta", {})
    for k in META_REQUIRED:
        if meta.get(k) in (None, "", []):
            errors.append(f"meta 缺少必填字段: {k}")

    stage = meta.get("stage", "")
    if stage and stage not in VALID_STAGES:
        errors.append(f"meta.stage 非法取值: {stage}（合法: {VALID_STAGES}）")
    mode = meta.get("mode", "")
    if mode and mode not in VALID_MODES:
        errors.append(f"meta.mode 非法取值: {mode}（合法: {VALID_MODES}）")
    if "anonymize" in meta and not isinstance(meta["anonymize"], bool):
        errors.append("meta.anonymize 必须为布尔值")

    records = data.get("records", [])
    if not isinstance(records, list):
        return meta, ["records 必须为数组"], []
    if not records:
        warnings.append("records 为空：没有任何答疑记录")

    # ── 逐条校验 ──
    type_count, tier_count, conf_count = {}, {}, {}
    confirm_pending, crisis_count, merged, faq_candidates = 0, 0, 0, 0
    id_seen = set()

    for i, rec in enumerate(records, start=1):
        rid = rec.get("id", f"#{i}")
        ctx = f"Q{i}"

        # 编号
        if "id" not in rec:
            errors.append(f"{ctx}: 缺少 id 字段")
        elif not check_id_format(rec["id"], i):
            errors.append(f"{ctx}: id 格式或序位错误: {rec['id']}（应为 Q{i:03d}）")
        if rec.get("id") in id_seen:
            errors.append(f"{ctx}: id 重复: {rec['id']}")
        id_seen.add(rec.get("id"))

        # 必填字段
        for k in RECORD_REQUIRED:
            v = rec.get(k)
            if v in (None, "", []):
                # same_as 合并记录允许 reply 简写，但仍需有非空占位说明
                if k.startswith("reply_") and rec.get("same_as"):
                    continue
                errors.append(f"{ctx}: 缺少必填字段: {k}")

        asker = rec.get("asker", "学员本人")
        if asker not in VALID_ASKERS + ["学员本人"]:
            errors.append(f"{ctx}: asker 非法取值: {asker}（合法: {VALID_ASKERS}）")

        question = rec.get("question", "")
        if question and len(question) > QUESTION_MAX_LEN:
            warnings.append(f"{ctx}: 问题原文超 {QUESTION_MAX_LEN} 字，请确认是否照片解析全文")

        # 诊断
        diag = rec.get("diagnosis", {})
        if not isinstance(diag, dict):
            errors.append(f"{ctx}: diagnosis 必须为对象")
            diag = {}
        for k in DIAG_REQUIRED:
            if k not in diag:
                errors.append(f"{ctx}: diagnosis 缺少字段: {k}")
        qtype = diag.get("question_type", "")
        if qtype and qtype not in VALID_TYPES:
            errors.append(f"{ctx}: question_type 非法取值: {qtype}")
        tier = diag.get("difficulty_tier", "")
        if tier and tier not in VALID_TIERS:
            errors.append(f"{ctx}: difficulty_tier 非法取值: {tier}")
        diff = diag.get("difficulty_estimate", "")
        if diff and diff not in VALID_DIFFS:
            errors.append(f"{ctx}: difficulty_estimate 非法取值: {diff}")
        if qtype == "题目求解型" and not diff:
            errors.append(f"{ctx}: 题目求解型必须填写 difficulty_estimate")
        kps = diag.get("knowledge_points", [])
        if kps and (not isinstance(kps, list) or len(kps) > 2):
            errors.append(f"{ctx}: knowledge_points 须为 0-2 个的数组")
        NO_KP_TYPES = ("事务服务型", "情绪态度型", "升学政策型")
        if qtype and qtype not in NO_KP_TYPES and kps == []:
            warnings.append(f"{ctx}: {qtype}建议至少标注 1 个知识点")

        # 教师确认纪律
        need_confirm = diag.get("need_teacher_confirm")
        if qtype in CONFIRM_REQUIRED_TYPES and need_confirm is not True:
            errors.append(f"{ctx}: {qtype} 必须 need_teacher_confirm=true")
        if need_confirm is True:
            confirm_pending += 1

        # 危机纪律
        if diag.get("crisis") is True:
            crisis_count += 1
            if rec.get("status") != "待教师确认":
                errors.append(f"{ctx}: crisis=true 时 status 必须为「待教师确认」")
            if not rec.get("follow_up"):
                errors.append(f"{ctx}: crisis=true 时 follow_up 必须含转介事项")

        # 双版本完备
        same_as = rec.get("same_as")
        if same_as:
            merged += 1
            if same_as in id_seen and same_as != rec.get("id"):
                pass  # 指向已出现的主问题，合法
            elif same_as not in [r.get("id") for r in records]:
                errors.append(f"{ctx}: same_as 指向不存在的问题号: {same_as}")
        else:
            sendable = rec.get("reply_sendable", "")
            confirm_reply = rec.get("reply_confirm", "")
            if sendable and len(sendable) > SENDABLE_MAX_LEN * 3:
                warnings.append(f"{ctx}: 可发送版超长（>{SENDABLE_MAX_LEN*3}字），请确认渠道适配")
            if sendable and confirm_reply and len(confirm_reply) < len(sendable):
                warnings.append(f"{ctx}: 待确认版比可发送版短，确认其是否含完整讲解")

        # 置信度与状态
        conf = rec.get("confidence", "")
        if conf and conf not in VALID_CONF:
            errors.append(f"{ctx}: confidence 非法取值: {conf}")
        status = rec.get("status", "待发送")
        if status and status not in VALID_STATUS:
            errors.append(f"{ctx}: status 非法取值: {status}")
        if conf == "低" and status == "已发送":
            errors.append(f"{ctx}: 低置信度记录禁止直接标记已发送")

        # FAQ 标记
        if rec.get("faq_worthy"):
            faq_candidates += 1
            if mode == "faq" and not rec.get("talk_track"):
                warnings.append(f"{ctx}: faq_worthy=true 但缺少 talk_track，FAQ 题库将缺话术模板行")
        freq = rec.get("faq_frequency", 1)
        if freq and (not isinstance(freq, (int, float)) or freq < 1):
            errors.append(f"{ctx}: faq_frequency 须为 ≥1 的数字")

        # 统计
        if qtype:
            type_count[qtype] = type_count.get(qtype, 0) + 1
        if tier:
            tier_count[tier] = tier_count.get(tier, 0) + 1
        if conf:
            conf_count[conf] = conf_count.get(conf, 0) + 1

    # ── 分布合理性提示 ──
    total = len(records)
    if total >= 10 and "题目求解型" not in type_count:
        warnings.append(f"{total} 条记录中没有题目求解型，请确认场景是否典型")
    low_ratio = conf_count.get("低", 0) / total if total else 0
    if total >= 10 and low_ratio > 0.3:
        warnings.append(f"低置信度占比 {low_ratio:.0%} 偏高，建议人工预核后再批量发送")

    stats = {
        "total": total,
        "type_distribution": type_count,
        "tier_distribution": tier_count,
        "confidence_distribution": conf_count,
        "need_teacher_confirm": confirm_pending,
        "crisis_flagged": crisis_count,
        "merged_same_as": merged,
        "faq_candidates": faq_candidates,
    }
    return stats, errors, warnings


def main():
    ap = argparse.ArgumentParser(description="校验 qa_records.json")
    ap.add_argument("path", help="qa_records.json 路径")
    ap.add_argument("--json", action="store_true", help="JSON 输出")
    ap.add_argument("--quiet", action="store_true", help="不输出统计")
    args = ap.parse_args()

    stats, errors, warnings = validate(args.path)

    if stats is None:
        if args.json:
            print(json.dumps({"ok": False, "errors": errors}, ensure_ascii=False))
        else:
            for e in errors:
                print(f"[ERROR] {e}")
        sys.exit(2)

    if args.json:
        print(json.dumps({"ok": not errors, "stats": stats,
                          "errors": errors, "warnings": warnings},
                         ensure_ascii=False, indent=2))
        sys.exit(1 if errors else 0)

    for e in errors:
        print(f"[ERROR] {e}")
    for w in warnings:
        print(f"[WARN]  {w}")

    if not args.quiet and stats:
        print("\n── 分布统计 ──")
        print(f"记录总数: {stats['total']}")
        print(f"分型分布: {stats['type_distribution']}")
        print(f"难度档分布: {stats['tier_distribution']}")
        print(f"置信度分布: {stats['confidence_distribution']}")
        print(f"待教师确认: {stats['need_teacher_confirm']}  危机标记: {stats['crisis_flagged']}")
        print(f"同题合并: {stats['merged_same_as']}  FAQ候选: {stats['faq_candidates']}")

    if errors:
        print(f"\n结果: ✗ 未通过（{len(errors)} errors / {len(warnings)} warnings）")
        sys.exit(1)
    print(f"\n结果: ✓ 通过（0 errors / {len(warnings)} warnings）")
    sys.exit(0)


if __name__ == "__main__":
    main()
