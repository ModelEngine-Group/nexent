# qa_records.json 字段字典

本文档定义答疑源文件 qa_records.json 的完整字段规范。Step 4 质量审查与 Step 5 交付时加载。

---

## 一、顶层结构

```json
{
  "meta": { ... },
  "records": [ ... ]
}
```

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| meta | object | 是 | 答疑作业元信息 |
| records | array | 是 | 答疑记录列表，按提问时间顺序排列 |

---

## 二、meta 字段（作业元信息）

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| course_name | string | 是 | — | 课程/班级名，如"八年级数学秋季班" |
| org_context | string | 否 | "" | 机构口径备注（如"不提前教韦达定理"） |
| stage | string | 是 | — | 学段：小学/初中/高中 |
| grade | string | 是 | — | 年级，如"八年级" |
| subject | string | 是 | — | 学科：语文/数学/英语/物理/化学/生物/政治/历史/地理/科学 |
| mode | string | 是 | — | 作业模式：instant（即时）/ batch（批量）/ faq（题库沉淀） |
| date | string | 否 | 当天 | 答疑日期 YYYY-MM-DD |
| anonymize | boolean | 否 | false | 交付物中学员姓名是否脱敏为"学员A/B" |

**示例：**

```json
{
  "meta": {
    "course_name": "八年级数学秋季班",
    "org_context": "一元二次方程不提前引入韦达定理",
    "stage": "初中",
    "grade": "八年级",
    "subject": "数学",
    "mode": "batch",
    "date": "2026-08-31",
    "anonymize": false
  }
}
```

> org_context 只写口径内容本身，不要带"机构口径："前缀（导出器会自动加）。

---

## 三、records 字段（答疑记录层）

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | string | 是 | — | 问题号：Q{三位全局序}（Q001…） |
| student | string | 是 | — | 学员姓名或"学员A"（anonymize 时） |
| asker | string | 否 | 学员本人 | 提问人：学员/家长/助教转述 |
| question | string | 是 | — | 问题原文（尽量保留原话） |
| question_time | string | 否 | — | 提问时间 HH:MM |
| diagnosis | object | 是 | — | 诊断结果（见下） |
| reply_sendable | string | 是 | — | 可发送版回复全文 |
| reply_confirm | string | 是 | — | 待确认版回复全文 |
| confidence | string | 是 | — | 高/中/低 |
| status | string | 否 | 待发送 | 待发送/已发送/待教师确认/已关闭 |
| follow_up | string | 否 | "" | 跟进备注（回访点/关联问题号/转介事项） |
| same_as | string | 否 | null | 同题合并时指向主问题号，如"Q003" |
| talk_track | string | 否 | — | 话术模板（挖空版，{学员名}等占位）；faq_worthy=true 的记录在 faq 模式下必填，导出器据此生成 FAQ 模板行与速查卡第三行 |
| faq_worthy | boolean | 否 | false | 是否建议沉淀入 FAQ 题库 |
| faq_frequency | number | 否 | 1 | 该问题（含同义问法）出现次数 |

**diagnosis 字段：**

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| question_type | string | 是 | 七分型之一：知识概念型/题目求解型/作业解析型/方法策略型/升学政策型/情绪态度型/事务服务型 |
| knowledge_points | array | 是 | 涉及知识点 0-2 个；事务服务型可为空数组 |
| difficulty_tier | string | 是 | 基础档/标准档/进阶档 |
| difficulty_estimate | string | 否 | 题目相对难度：易/中/难（题目求解型必填） |
| beyond_syllabus | boolean | 否 | false | 主讲法是否超学段大纲 |
| strategy | string | 是 | 讲解策略链（一句话） |
| need_teacher_confirm | boolean | 是 | 题目求解/升学政策/情绪黄色以上必须 true |
| crisis | boolean | 否 | false | 是否出现红色危机信号 |
| confirm_notes | string | 否 | 待确认事项说明 |

---

## 四、枚举约束汇总

| 枚举 | 合法值 |
|------|--------|
| mode | instant / batch / faq |
| stage | 小学 / 初中 / 高中 |
| question_type | 知识概念型 / 题目求解型 / 作业解析型 / 方法策略型 / 升学政策型 / 情绪态度型 / 事务服务型 |
| difficulty_tier | 基础档 / 标准档 / 进阶档 |
| difficulty_estimate | 易 / 中 / 难 |
| confidence | 高 / 中 / 低 |
| status | 待发送 / 已发送 / 待教师确认 / 已关闭 |
| asker | 学员 / 家长 / 助教转述 |

---

## 五、同题合并与 FAQ 标记规则

1. `same_as` 指向主问题号；被合并记录仍保留原文与诊断，reply 字段可写"同 Q003"
2. `faq_worthy=true` 的判定：faq_frequency ≥3，或教师标记，或分型为知识概念型且问法典型
3. `crisis=true` 的记录：status 必须为"待教师确认"，且 follow_up 必须含转介事项
4. ID 编号全局连续不重不跳；合并记录不改号
